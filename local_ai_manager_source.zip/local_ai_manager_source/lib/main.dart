import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_background/flutter_background.dart';
import 'package:llama_flutter_android/llama_flutter_android.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const int kDefaultPort = 11435;
const String kModelId = 'shared';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ManagerSettings.ensureDefaults();
  runApp(const LocalAiManagerApp());
}

class LocalAiManagerApp extends StatelessWidget {
  const LocalAiManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Local AI Manager',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: ThemeMode.system,
      home: const ManagerHomePage(),
    );
  }
}

class AppProfile {
  final String name;
  final String packageName;

  const AppProfile({required this.name, required this.packageName});

  Map<String, dynamic> toJson() => {'name': name, 'package': packageName};

  static AppProfile fromJson(Map<String, dynamic> json) => AppProfile(
        name: (json['name'] ?? '').toString(),
        packageName: (json['package'] ?? '').toString(),
      );
}

class ManagerSettings {
  static const _modelPath = 'manager_model_path';
  static const _modelName = 'manager_model_name';
  static const _idleSeconds = 'manager_idle_seconds';
  static const _port = 'manager_port';
  static const _gpu = 'manager_gpu';
  static const _profiles = 'manager_profiles';

  static Future<void> ensureDefaults() async {
    final p = await SharedPreferences.getInstance();
    if (!p.containsKey(_idleSeconds)) await p.setInt(_idleSeconds, 120);
    if (!p.containsKey(_port)) await p.setInt(_port, kDefaultPort);
    if (!p.containsKey(_gpu)) await p.setBool(_gpu, false);
    if (!p.containsKey(_profiles)) {
      await saveProfiles(const [
        AppProfile(name: 'Memora', packageName: 'com.memora.memora'),
        AppProfile(
          name: 'Finanzas',
          packageName: 'com.angel.finanzas.finanzas_definitiva',
        ),
      ]);
    }
  }

  static Future<String> modelPath() async =>
      (await SharedPreferences.getInstance()).getString(_modelPath) ?? '';
  static Future<String> modelName() async =>
      (await SharedPreferences.getInstance()).getString(_modelName) ?? '';
  static Future<int> idleSeconds() async =>
      (await SharedPreferences.getInstance()).getInt(_idleSeconds) ?? 120;
  static Future<int> port() async =>
      (await SharedPreferences.getInstance()).getInt(_port) ?? kDefaultPort;
  static Future<bool> useGpu() async =>
      (await SharedPreferences.getInstance()).getBool(_gpu) ?? false;

  static Future<void> setModel(String path, String name) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_modelPath, path);
    await p.setString(_modelName, name);
  }

  static Future<void> setIdleSeconds(int value) async =>
      (await SharedPreferences.getInstance()).setInt(_idleSeconds, value);
  static Future<void> setGpu(bool value) async =>
      (await SharedPreferences.getInstance()).setBool(_gpu, value);

  static Future<List<AppProfile>> profiles() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList(_profiles) ?? const [];
    return raw
        .map((e) => AppProfile.fromJson(jsonDecode(e) as Map<String, dynamic>))
        .where((e) => e.name.trim().isNotEmpty)
        .toList();
  }

  static Future<void> saveProfiles(List<AppProfile> profiles) async {
    await (await SharedPreferences.getInstance()).setStringList(
      _profiles,
      profiles.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }
}

class EngineStatus {
  final bool serverRunning;
  final bool modelLoaded;
  final bool generating;
  final String modelName;
  final String acceleration;
  final int rssMb;
  final int requestCount;
  final DateTime? lastUsed;
  final String? error;

  const EngineStatus({
    required this.serverRunning,
    required this.modelLoaded,
    required this.generating,
    required this.modelName,
    required this.acceleration,
    required this.rssMb,
    required this.requestCount,
    required this.lastUsed,
    this.error,
  });
}

class SharedLlamaEngine {
  LlamaController? _controller;
  String _loadedPath = '';
  bool _generating = false;
  String _acceleration = 'Sin cargar';
  DateTime? _lastUsed;
  int _requestCount = 0;
  Timer? _idleTimer;
  Future<void> _queue = Future<void>.value();

  bool get loaded => _controller != null;
  bool get generating => _generating;
  String get acceleration => _acceleration;
  DateTime? get lastUsed => _lastUsed;
  int get requestCount => _requestCount;

  Future<T> serial<T>(Future<T> Function() action) {
    final c = Completer<T>();
    _queue = _queue.then((_) async {
      try {
        c.complete(await action());
      } catch (e, st) {
        c.completeError(e, st);
      }
    }).catchError((_) {});
    return c.future;
  }

  Future<void> _ensureLoaded() async {
    final path = await ManagerSettings.modelPath();
    if (path.isEmpty || !File(path).existsSync()) {
      throw StateError('No hay un modelo GGUF configurado en Local AI Manager.');
    }
    if (_controller != null && _loadedPath == path) return;
    await unload();

    final controller = LlamaController();
    final threads = max(2, min(8, Platform.numberOfProcessors - 2));
    var gpuLayers = 0;
    var gpuName = '';
    if (await ManagerSettings.useGpu()) {
      try {
        final gpu = await controller.detectGpu();
        if (gpu.vulkanSupported) {
          gpuLayers = gpu.recommendedGpuLayers;
          gpuName = gpu.gpuName;
        }
      } catch (_) {
        gpuLayers = 0;
      }
    }

    try {
      await controller.loadModel(
        modelPath: path,
        threads: threads,
        contextSize: 4096,
        gpuLayers: gpuLayers,
      );
      _controller = controller;
      _loadedPath = path;
      _acceleration = gpuLayers > 0
          ? 'GPU Vulkan${gpuName.isEmpty ? '' : ' • $gpuName'}'
          : 'CPU • $threads hilos';
    } catch (_) {
      try {
        await controller.dispose();
      } catch (_) {}
      rethrow;
    }
  }

  Future<String> generate({
    required List<ChatMessage> messages,
    required int maxTokens,
    required double temperature,
  }) {
    return serial(() async {
      await _ensureLoaded();
      final controller = _controller!;
      _generating = true;
      _idleTimer?.cancel();
      final out = StringBuffer();
      try {
        await for (final token in controller.generateChat(
          messages: messages,
          temperature: temperature.clamp(0.0, 2.0).toDouble(),
          maxTokens: maxTokens.clamp(32, 1024).toInt(),
        )) {
          out.write(token);
        }
        _requestCount++;
        _lastUsed = DateTime.now();
        return out.toString().trim();
      } finally {
        _generating = false;
        _scheduleUnload();
      }
    });
  }

  Future<void> stop() async {
    try {
      await _controller?.stop();
    } catch (_) {}
  }

  Future<void> unload() async {
    _idleTimer?.cancel();
    _idleTimer = null;
    final current = _controller;
    _controller = null;
    _loadedPath = '';
    _acceleration = 'Sin cargar';
    if (current != null) {
      try {
        await current.stop();
      } catch (_) {}
      try {
        await current.dispose();
      } catch (_) {}
    }
  }

  Future<void> _scheduleUnload() async {
    _idleTimer?.cancel();
    final seconds = await ManagerSettings.idleSeconds();
    _idleTimer = Timer(Duration(seconds: seconds), () async {
      if (!_generating) await unload();
    });
  }
}

class LocalAiServer {
  final SharedLlamaEngine engine;
  HttpServer? _server;
  String? lastError;

  LocalAiServer(this.engine);

  bool get running => _server != null;

  Future<void> start() async {
    if (_server != null) return;
    final port = await ManagerSettings.port();
    try {
      _server = await HttpServer.bind(InternetAddress.loopbackIPv4, port);
      _server!.listen(_handle, onError: (Object e) => lastError = e.toString());
      lastError = null;
    } catch (e) {
      lastError = e.toString();
      rethrow;
    }
  }

  Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
    await engine.unload();
  }

  Future<void> _handle(HttpRequest request) async {
    request.response.headers.contentType = ContentType.json;
    request.response.headers.set('Access-Control-Allow-Origin', '*');
    try {
      final path = request.uri.path;
      if (request.method == 'GET' && (path == '/health' || path == '/status')) {
        await _writeJson(request.response, 200, await _statusJson());
        return;
      }
      if (request.method == 'GET' && path == '/v1/models') {
        await _writeJson(request.response, 200, {
          'object': 'list',
          'data': [
            {'id': kModelId, 'object': 'model', 'owned_by': 'local-ai-manager'}
          ],
        });
        return;
      }
      if (request.method == 'POST' && path == '/unload') {
        await engine.unload();
        await _writeJson(request.response, 200, {'ok': true, 'model_loaded': false});
        return;
      }
      if (request.method == 'POST' && path == '/stop') {
        await engine.stop();
        await _writeJson(request.response, 200, {'ok': true});
        return;
      }
      if (request.method == 'POST' && path == '/v1/chat/completions') {
        final text = await utf8.decoder.bind(request).join();
        final body = jsonDecode(text) as Map<String, dynamic>;
        final rawMessages = (body['messages'] as List?) ?? const [];
        if (rawMessages.isEmpty) {
          throw const FormatException('messages no puede estar vacío');
        }
        final messages = <ChatMessage>[];
        for (final item in rawMessages) {
          if (item is! Map) continue;
          final role = (item['role'] ?? 'user').toString();
          final content = _flattenContent(item['content']);
          if (content.trim().isNotEmpty) {
            messages.add(ChatMessage(role: role, content: content));
          }
        }
        if (messages.isEmpty) throw const FormatException('No hay mensajes válidos');
        final maxTokens = _asInt(body['max_tokens'], 320);
        final temperature = _asDouble(body['temperature'], 0.25);
        final answer = await engine.generate(
          messages: messages,
          maxTokens: maxTokens,
          temperature: temperature,
        );
        await _writeJson(request.response, 200, {
          'id': 'local-${DateTime.now().millisecondsSinceEpoch}',
          'object': 'chat.completion',
          'created': DateTime.now().millisecondsSinceEpoch ~/ 1000,
          'model': kModelId,
          'choices': [
            {
              'index': 0,
              'message': {'role': 'assistant', 'content': answer},
              'finish_reason': 'stop',
            }
          ],
        });
        return;
      }
      await _writeJson(request.response, 404, {
        'error': {'message': 'Ruta no encontrada: $path'}
      });
    } catch (e) {
      lastError = e.toString();
      await _writeJson(request.response, 500, {
        'error': {'message': _cleanError(e)}
      });
    }
  }

  Future<Map<String, dynamic>> _statusJson() async => {
        'ok': true,
        'server': running,
        'model_loaded': engine.loaded,
        'generating': engine.generating,
        'model': await ManagerSettings.modelName(),
        'acceleration': engine.acceleration,
        'rss_mb': await processRssMb(),
        'requests': engine.requestCount,
        'last_used': engine.lastUsed?.toIso8601String(),
        if (lastError != null) 'last_error': lastError,
      };

  static String _flattenContent(dynamic content) {
    if (content is String) return content;
    if (content is List) {
      final parts = <String>[];
      for (final item in content) {
        if (item is Map && item['type'] == 'text') {
          parts.add((item['text'] ?? '').toString());
        }
      }
      return parts.join('\n');
    }
    return content?.toString() ?? '';
  }

  static int _asInt(dynamic value, int fallback) {
    if (value is int) return value;
    return int.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static double _asDouble(dynamic value, double fallback) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '') ?? fallback;
  }

  static Future<void> _writeJson(HttpResponse response, int status, Object body) async {
    response.statusCode = status;
    response.write(jsonEncode(body));
    await response.close();
  }

  static String _cleanError(Object e) {
    var s = e.toString();
    if (s.startsWith('Bad state: ')) s = s.substring('Bad state: '.length);
    if (s.startsWith('FormatException: ')) s = s.substring('FormatException: '.length);
    return s;
  }
}

Future<int> processRssMb() async {
  try {
    final lines = await File('/proc/self/status').readAsLines();
    final line = lines.firstWhere((e) => e.startsWith('VmRSS:'));
    final kb = int.tryParse(RegExp(r'\d+').firstMatch(line)?.group(0) ?? '') ?? 0;
    return (kb / 1024).round();
  } catch (_) {
    return 0;
  }
}

final SharedLlamaEngine sharedEngine = SharedLlamaEngine();
final LocalAiServer localServer = LocalAiServer(sharedEngine);

class ManagerHomePage extends StatefulWidget {
  const ManagerHomePage({super.key});

  @override
  State<ManagerHomePage> createState() => _ManagerHomePageState();
}

class _ManagerHomePageState extends State<ManagerHomePage> {
  Timer? _timer;
  bool _busy = true;
  bool _backgroundEnabled = false;
  bool _gpu = false;
  int _idleSeconds = 120;
  String _modelName = '';
  String _modelPath = '';
  List<AppProfile> _profiles = const [];
  EngineStatus _status = const EngineStatus(
    serverRunning: false,
    modelLoaded: false,
    generating: false,
    modelName: '',
    acceleration: 'Sin cargar',
    rssMb: 0,
    requestCount: 0,
    lastUsed: null,
  );

  @override
  void initState() {
    super.initState();
    _init();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refreshStatus());
  }

  Future<void> _init() async {
    await _enableBackground();
    _gpu = await ManagerSettings.useGpu();
    _idleSeconds = await ManagerSettings.idleSeconds();
    _modelName = await ManagerSettings.modelName();
    _modelPath = await ManagerSettings.modelPath();
    _profiles = await ManagerSettings.profiles();
    try {
      await localServer.start();
    } catch (_) {}
    await _refreshStatus();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _enableBackground() async {
    const config = FlutterBackgroundAndroidConfig(
      notificationTitle: 'Local AI Manager',
      notificationText: 'Compartiendo el modelo local con tus APKs',
      notificationImportance: AndroidNotificationImportance.normal,
      notificationIcon: AndroidResource(name: 'ic_launcher', defType: 'mipmap'),
      shouldRequestBatteryOptimizationsOff: false,
      showBadge: false,
    );
    try {
      final initialized = await FlutterBackground.initialize(androidConfig: config);
      if (initialized) {
        _backgroundEnabled = await FlutterBackground.enableBackgroundExecution();
      }
    } catch (_) {
      _backgroundEnabled = false;
    }
  }

  Future<void> _refreshStatus() async {
    if (!mounted) return;
    final status = EngineStatus(
      serverRunning: localServer.running,
      modelLoaded: sharedEngine.loaded,
      generating: sharedEngine.generating,
      modelName: await ManagerSettings.modelName(),
      acceleration: sharedEngine.acceleration,
      rssMb: await processRssMb(),
      requestCount: sharedEngine.requestCount,
      lastUsed: sharedEngine.lastUsed,
      error: localServer.lastError,
    );
    if (mounted) setState(() => _status = status);
  }

  Future<void> _pickModel() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['gguf'],
      withData: false,
    );
    final sourcePath = result?.files.single.path;
    if (sourcePath == null || sourcePath.isEmpty) return;
    setState(() => _busy = true);
    try {
      await sharedEngine.unload();
      final dir = Directory('${(await getApplicationSupportDirectory()).path}/models');
      await dir.create(recursive: true);
      final source = File(sourcePath);
      final fileName = result!.files.single.name;
      final target = File('${dir.path}/$fileName');
      if (await target.exists()) await target.delete();
      await source.copy(target.path);
      await ManagerSettings.setModel(target.path, fileName);
      _modelName = fileName;
      _modelPath = target.path;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Modelo importado. Se cargará cuando una APK lo necesite.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No pude importar el modelo: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
      await _refreshStatus();
    }
  }

  Future<void> _unloadNow() async {
    await sharedEngine.unload();
    await _refreshStatus();
  }

  Future<void> _testModel() async {
    setState(() => _busy = true);
    try {
      final text = await sharedEngine.generate(
        messages: [
          ChatMessage(role: 'user', content: 'Responde solamente: OK'),
        ],
        maxTokens: 24,
        temperature: 0.0,
      );
      if (mounted) {
        showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Prueba del modelo'),
            content: Text(text.isEmpty ? 'Sin respuesta' : text),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar'))],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
      await _refreshStatus();
    }
  }

  Future<void> _addApp() async {
    final name = TextEditingController();
    final pkg = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Agregar APK'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')),
            const SizedBox(height: 8),
            TextField(controller: pkg, decoration: const InputDecoration(labelText: 'Package (opcional)')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Agregar')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    final updated = [..._profiles, AppProfile(name: name.text.trim(), packageName: pkg.text.trim())];
    await ManagerSettings.saveProfiles(updated);
    if (mounted) setState(() => _profiles = updated);
  }

  Future<void> _removeApp(int index) async {
    final updated = [..._profiles]..removeAt(index);
    await ManagerSettings.saveProfiles(updated);
    if (mounted) setState(() => _profiles = updated);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final baseUrl = 'http://127.0.0.1:$kDefaultPort/v1';
    return Scaffold(
      appBar: AppBar(title: const Text('Local AI Manager')),
      body: _busy && _modelName.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Estado', style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 10),
                        _statusRow('Servidor', _status.serverRunning ? 'Activo' : 'Detenido'),
                        _statusRow('Segundo plano', _backgroundEnabled ? 'Activo' : 'Limitado'),
                        _statusRow('Modelo', _status.modelLoaded ? 'Cargado' : 'Fuera de RAM'),
                        _statusRow('Inferencia', _status.generating ? 'Generando' : 'Libre'),
                        _statusRow('Aceleración', _status.acceleration),
                        _statusRow('RAM del gestor', '${_status.rssMb} MB aprox.'),
                        _statusRow('Solicitudes', '${_status.requestCount}'),
                        if (_status.error != null) ...[
                          const SizedBox(height: 8),
                          Text(_status.error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Modelo compartido', style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 8),
                        Text(_modelName.isEmpty ? 'No configurado' : _modelName),
                        if (_modelPath.isNotEmpty)
                          Text(_modelPath, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            FilledButton.icon(onPressed: _busy ? null : _pickModel, icon: const Icon(Icons.folder_open), label: const Text('Elegir GGUF')),
                            OutlinedButton.icon(onPressed: _busy || _modelName.isEmpty ? null : _testModel, icon: const Icon(Icons.play_arrow), label: const Text('Probar')),
                            OutlinedButton.icon(onPressed: _status.modelLoaded ? _unloadNow : null, icon: const Icon(Icons.memory), label: const Text('Liberar RAM')),
                          ],
                        ),
                        const Divider(height: 28),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          value: _gpu,
                          title: const Text('Usar GPU/Vulkan'),
                          subtitle: const Text('Desactivado por defecto para máxima estabilidad.'),
                          onChanged: (v) async {
                            await sharedEngine.unload();
                            await ManagerSettings.setGpu(v);
                            setState(() => _gpu = v);
                          },
                        ),
                        Text('Liberar modelo después de $_idleSeconds s sin uso'),
                        Slider(
                          value: _idleSeconds.toDouble(),
                          min: 30,
                          max: 600,
                          divisions: 19,
                          label: '${_idleSeconds}s',
                          onChanged: (v) => setState(() => _idleSeconds = v.round()),
                          onChangeEnd: (v) => ManagerSettings.setIdleSeconds(v.round()),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Conexión para las APKs', style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 8),
                        SelectableText('Base URL: $baseUrl\nModelo: $kModelId\nAPI key: dejar vacía'),
                        const SizedBox(height: 8),
                        const Text('Memora y Finanzas pueden usar su opción Ollama / servidor local / OpenAI compatible con estos datos.'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text('APKs', style: Theme.of(context).textTheme.titleLarge)),
                            IconButton(onPressed: _addApp, icon: const Icon(Icons.add), tooltip: 'Agregar APK'),
                          ],
                        ),
                        const Text('Memora y Finanzas vienen preparadas. Puedes registrar más apps y conectarlas al mismo servidor local.'),
                        const SizedBox(height: 8),
                        for (var i = 0; i < _profiles.length; i++)
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            leading: const Icon(Icons.apps),
                            title: Text(_profiles[i].name),
                            subtitle: _profiles[i].packageName.isEmpty ? null : Text(_profiles[i].packageName),
                            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => _removeApp(i)),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _statusRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Flexible(child: Text(value, textAlign: TextAlign.right)),
          ],
        ),
      );
}
