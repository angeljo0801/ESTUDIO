# Suite Personal

Aplicación Android/Flutter con 10 módulos integrados:

1. Memora Pro — biblioteca local, búsqueda, etiquetas y resumen rápido.
2. Finanzas Tutor IA — conceptos y pruebas de finanzas.
3. Business Control — ingresos, gastos e inventario.
4. Decisiones financieras — ROI, VAN simple y punto de equilibrio.
5. Study Lock — sesiones de concentración y bloqueo de salida dentro de la app.
6. Smart Tasks — tareas y subtareas persistentes.
7. Daily Brief Offline — lector RSS con caché local y deduplicación por título.
8. Travel Hunter — búsqueda rápida de vuelos en Google Flights y Skyscanner; preparado para APIs agregadoras.
9. Price Scanner — OCR desde cámara/galería y extracción de precios.
10. Personal Dashboard — resumen de tareas, biblioteca, noticias y negocio.

Los datos se guardan localmente en el teléfono. Las búsquedas web y la actualización RSS necesitan Internet. Las búsquedas de vuelos agregadas dentro de la app requieren credenciales de Skyscanner, Duffel o Amadeus.
