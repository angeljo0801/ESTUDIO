import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:xml/xml.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PersonalSuiteApp());
}

class PersonalSuiteApp extends StatelessWidget {
  const PersonalSuiteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Suite Personal',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const SuiteHomePage(),
    );
  }
}

class Store {
  static Future<List<Map<String, dynamic>>> list(String key) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(key);
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveList(String key, List<Map<String, dynamic>> value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, jsonEncode(value));
  }

  static Future<String> text(String key, [String fallback = '']) async {
    final p = await SharedPreferences.getInstance();
    return p.getString(key) ?? fallback;
  }

  static Future<void> saveText(String key, String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(key, value);
  }
}

String money(num n) => '\$${n.toStringAsFixed(2)}';
String today() {
  final d = DateTime.now();
  return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

double number(String s) => double.tryParse(s.replaceAll(',', '').replaceAll('\$', '').trim()) ?? 0;

class SuiteHomePage extends StatelessWidget {
  const SuiteHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final modules = <_Module>[
      _Module('Memora Pro', 'Biblioteca, notas y resúmenes', Icons.auto_stories, const MemoraPage()),
      _Module('Finanzas Tutor IA', 'Conceptos, práctica y pruebas', Icons.school, const FinanceTutorPage()),
      _Module('Business Control', 'Ingresos, gastos e inventario', Icons.storefront, const BusinessPage()),
      _Module('Decisiones financieras', 'ROI, VAN y punto de equilibrio', Icons.calculate, const DecisionsPage()),
      _Module('Study Lock', 'Sesiones de concentración', Icons.lock_clock, const StudyLockPage()),
      _Module('Smart Tasks', 'Tareas y subtareas', Icons.task_alt, const TasksPage()),
      _Module('Daily Brief Offline', 'RSS y lectura guardada', Icons.newspaper, const DailyBriefPage()),
      _Module('Travel Hunter', 'Vuelos y accesos de búsqueda', Icons.flight_takeoff, const TravelHunterPage()),
      _Module('Price Scanner', 'OCR y extracción de precios', Icons.document_scanner, const PriceScannerPage()),
      _Module('Personal Dashboard', 'Resumen de toda la suite', Icons.dashboard_customize, const DashboardPage()),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Suite Personal'), actions: [
        IconButton(
          tooltip: 'Dashboard',
          icon: const Icon(Icons.dashboard),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DashboardPage())),
        ),
      ]),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 1.05,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: modules.length,
        itemBuilder: (context, i) {
          final m = modules[i];
          return Card(
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => m.page)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(m.icon, size: 36),
                  const Spacer(),
                  Text(m.title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(m.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Module {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget page;
  _Module(this.title, this.subtitle, this.icon, this.page);
}

class MemoraPage extends StatefulWidget {
  const MemoraPage({super.key});
  @override
  State<MemoraPage> createState() => _MemoraPageState();
}

class _MemoraPageState extends State<MemoraPage> {
  List<Map<String, dynamic>> notes = [];
  String q = '';
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    notes = await Store.list('memora_notes');
    if (mounted) setState(() {});
  }

  String _summary(String text) {
    final clean = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length <= 260) return clean;
    final parts = clean.split(RegExp(r'(?<=[.!?])\s+'));
    final s = parts.take(3).join(' ');
    return s.length > 300 ? '${s.substring(0, 300)}…' : s;
  }

  Future<void> _edit([Map<String, dynamic>? old]) async {
    final title = TextEditingController(text: old?['title']?.toString() ?? '');
    final body = TextEditingController(text: old?['body']?.toString() ?? '');
    final tags = TextEditingController(text: old?['tags']?.toString() ?? '');
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(old == null ? 'Nueva entrada' : 'Editar entrada'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Título')),
          TextField(controller: tags, decoration: const InputDecoration(labelText: 'Etiquetas (separadas por coma)')),
          TextField(controller: body, minLines: 5, maxLines: 12, decoration: const InputDecoration(labelText: 'Contenido')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Guardar')),
        ],
      ),
    );
    if (result != true || title.text.trim().isEmpty) return;
    final item = {
      'id': old?['id'] ?? DateTime.now().microsecondsSinceEpoch,
      'title': title.text.trim(),
      'body': body.text.trim(),
      'tags': tags.text.trim(),
      'updated': DateTime.now().toIso8601String(),
    };
    if (old == null) {
      notes.insert(0, item);
    } else {
      final idx = notes.indexWhere((e) => e['id'] == old['id']);
      if (idx >= 0) notes[idx] = item;
    }
    await Store.saveList('memora_notes', notes);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final filtered = notes.where((n) {
      final all = '${n['title']} ${n['body']} ${n['tags']}'.toLowerCase();
      return all.contains(q.toLowerCase());
    }).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Memora Pro')),
      floatingActionButton: FloatingActionButton(onPressed: () => _edit(), child: const Icon(Icons.add)),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'Buscar en tu biblioteca', border: OutlineInputBorder())),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('Añade apuntes, guías, ideas o información.'))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final n = filtered[i];
                    return Card(child: ListTile(
                      title: Text(n['title']?.toString() ?? ''),
                      subtitle: Text(_summary(n['body']?.toString() ?? ''), maxLines: 3, overflow: TextOverflow.ellipsis),
                      onTap: () => showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        builder: (_) => SafeArea(child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(n['title']?.toString() ?? '', style: Theme.of(context).textTheme.headlineSmall),
                            if ((n['tags']?.toString() ?? '').isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text('Etiquetas: ${n['tags']}')),
                            const Divider(),
                            SelectableText(n['body']?.toString() ?? ''),
                            const SizedBox(height: 18),
                            Text('Resumen rápido', style: Theme.of(context).textTheme.titleMedium),
                            Text(_summary(n['body']?.toString() ?? '')),
                          ])),
                        )),
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) async {
                          if (v == 'edit') _edit(n);
                          if (v == 'delete') {
                            notes.removeWhere((e) => e['id'] == n['id']);
                            await Store.saveList('memora_notes', notes);
                            setState(() {});
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'edit', child: Text('Editar')),
                          PopupMenuItem(value: 'delete', child: Text('Eliminar')),
                        ],
                      ),
                    ));
                  },
                ),
        ),
      ]),
    );
  }
}

class FinanceTutorPage extends StatelessWidget {
  const FinanceTutorPage({super.key});
  static final lessons = <Map<String, dynamic>>[
    {'t': 'Capital de trabajo', 'd': 'Activo corriente − Pasivo corriente. Mide el colchón operativo de corto plazo.'},
    {'t': 'Margen bruto', 'd': '(Ventas − Costo de ventas) / Ventas. Mide cuánto queda después del costo directo.'},
    {'t': 'ROI', 'd': '(Ganancia de la inversión / Inversión inicial) × 100.'},
    {'t': 'Valor presente', 'd': 'VP = VF / (1+r)^n. Trae un flujo futuro al valor de hoy.'},
    {'t': 'Valor futuro', 'd': 'VF = VP × (1+r)^n. Proyecta cuánto crecerá un valor actual.'},
    {'t': 'Costo de capital', 'd': 'Rendimiento mínimo exigido por quienes financian la empresa.'},
    {'t': 'Flujo de caja', 'd': 'Entradas de efectivo − salidas de efectivo durante un período.'},
    {'t': 'Punto de equilibrio', 'd': 'Costos fijos / (Precio unitario − Costo variable unitario).'},
    {'t': 'Bono', 'd': 'Instrumento de deuda: el emisor recibe capital y promete intereses y devolución del principal.'},
    {'t': 'Liquidez', 'd': 'Capacidad de convertir un activo en efectivo rápidamente con poca pérdida de valor.'},
    {'t': 'VAN', 'd': 'Suma de flujos descontados menos la inversión inicial. VAN positivo suele indicar creación de valor.'},
    {'t': 'TIR', 'd': 'Tasa que hace que el VAN sea igual a cero.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Finanzas Tutor IA')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FinanceQuizPage(items: [...lessons]..shuffle()))),
        icon: const Icon(Icons.quiz), label: const Text('Prueba'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: lessons.length,
        itemBuilder: (_, i) => Card(child: ExpansionTile(title: Text(lessons[i]['t']), children: [Padding(padding: const EdgeInsets.all(16), child: Text(lessons[i]['d']))])),
      ),
    );
  }
}

class FinanceQuizPage extends StatefulWidget {
  final List<Map<String, dynamic>> items;
  const FinanceQuizPage({super.key, required this.items});
  @override
  State<FinanceQuizPage> createState() => _FinanceQuizPageState();
}

class _FinanceQuizPageState extends State<FinanceQuizPage> {
  int index = 0;
  int score = 0;
  bool answered = false;
  late List<String> options;
  @override
  void initState() {
    super.initState();
    _makeOptions();
  }

  void _makeOptions() {
    final correct = widget.items[index]['d'].toString();
    final pool = widget.items.map((e) => e['d'].toString()).where((e) => e != correct).toList()..shuffle();
    options = [correct, ...pool.take(3)]..shuffle();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.items[index];
    return Scaffold(
      appBar: AppBar(title: Text('Pregunta ${index + 1}/${widget.items.length}')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('¿Cuál definición corresponde a “${item['t']}”?', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 18),
          ...options.map((o) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: FilledButton.tonal(
              onPressed: answered ? null : () {
                final ok = o == item['d'];
                if (ok) score++;
                setState(() => answered = true);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Correcto' : 'Incorrecto. Respuesta: ${item['d']}')));
              },
              child: Padding(padding: const EdgeInsets.all(12), child: Text(o)),
            ),
          )),
          const Spacer(),
          if (answered) FilledButton(
            onPressed: () {
              if (index == widget.items.length - 1) {
                showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Resultado'), content: Text('Puntuación: $score/${widget.items.length}'), actions: [TextButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: const Text('Terminar'))]));
              } else {
                setState(() { index++; answered = false; _makeOptions(); });
              }
            },
            child: Text(index == widget.items.length - 1 ? 'Ver resultado' : 'Siguiente'),
          ),
        ]),
      ),
    );
  }
}

class BusinessPage extends StatefulWidget {
  const BusinessPage({super.key});
  @override
  State<BusinessPage> createState() => _BusinessPageState();
}

class _BusinessPageState extends State<BusinessPage> with SingleTickerProviderStateMixin {
  List<Map<String, dynamic>> moves = [];
  List<Map<String, dynamic>> inventory = [];
  late TabController tabs;
  @override
  void initState() {
    super.initState();
    tabs = TabController(length: 2, vsync: this);
    _load();
  }
  @override
  void dispose() { tabs.dispose(); super.dispose(); }
  Future<void> _load() async {
    moves = await Store.list('business_moves');
    inventory = await Store.list('business_inventory');
    if (mounted) setState(() {});
  }

  Future<void> _addMove() async {
    final desc = TextEditingController();
    final amount = TextEditingController();
    String type = 'Ingreso';
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, ss) => AlertDialog(
      title: const Text('Nuevo movimiento'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(value: type, items: ['Ingreso','Gasto'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => ss(() => type = v ?? type)),
        TextField(controller: desc, decoration: const InputDecoration(labelText: 'Descripción')),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Importe')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Guardar'))],
    )));
    if (ok != true || number(amount.text) <= 0) return;
    moves.insert(0, {'id': DateTime.now().microsecondsSinceEpoch, 'type': type, 'desc': desc.text.trim(), 'amount': number(amount.text), 'date': today()});
    await Store.saveList('business_moves', moves);
    setState(() {});
  }

  Future<void> _addProduct() async {
    final name = TextEditingController();
    final qty = TextEditingController();
    final price = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: const Text('Producto'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')),
        TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cantidad')),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Costo/precio unitario')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Guardar'))],
    ));
    if (ok != true || name.text.trim().isEmpty) return;
    inventory.insert(0, {'id': DateTime.now().microsecondsSinceEpoch, 'name': name.text.trim(), 'qty': number(qty.text), 'price': number(price.text)});
    await Store.saveList('business_inventory', inventory);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final income = moves.where((e) => e['type'] == 'Ingreso').fold<double>(0, (a, b) => a + number('${b['amount']}'));
    final expense = moves.where((e) => e['type'] == 'Gasto').fold<double>(0, (a, b) => a + number('${b['amount']}'));
    return Scaffold(
      appBar: AppBar(title: const Text('Business Control'), bottom: TabBar(controller: tabs, tabs: const [Tab(text: 'Movimientos'), Tab(text: 'Inventario')])),
      floatingActionButton: FloatingActionButton(onPressed: () => tabs.index == 0 ? _addMove() : _addProduct(), child: const Icon(Icons.add)),
      body: TabBarView(controller: tabs, children: [
        Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: Row(children: [
            Expanded(child: _StatCard('Ingresos', money(income), Icons.arrow_downward)),
            const SizedBox(width: 8),
            Expanded(child: _StatCard('Gastos', money(expense), Icons.arrow_upward)),
            const SizedBox(width: 8),
            Expanded(child: _StatCard('Neto', money(income-expense), Icons.account_balance_wallet)),
          ])),
          Expanded(child: ListView.builder(itemCount: moves.length, itemBuilder: (_, i) { final m = moves[i]; return Dismissible(
            key: ValueKey(m['id']),
            background: Container(color: Colors.red, alignment: Alignment.centerRight, padding: const EdgeInsets.all(16), child: const Icon(Icons.delete)),
            onDismissed: (_) async { moves.removeAt(i); await Store.saveList('business_moves', moves); setState(() {}); },
            child: ListTile(leading: Icon(m['type'] == 'Ingreso' ? Icons.add_circle : Icons.remove_circle), title: Text(m['desc']?.toString().isEmpty == false ? m['desc'] : m['type']), subtitle: Text(m['date'] ?? ''), trailing: Text(money(number('${m['amount']}')))),
          ); })),
        ]),
        ListView.builder(itemCount: inventory.length, itemBuilder: (_, i) { final p = inventory[i]; return Dismissible(
          key: ValueKey(p['id']),
          onDismissed: (_) async { inventory.removeAt(i); await Store.saveList('business_inventory', inventory); setState(() {}); },
          background: Container(color: Colors.red),
          child: ListTile(title: Text(p['name']), subtitle: Text('Cantidad: ${p['qty']}'), trailing: Text(money(number('${p['price']}')))),
        ); }),
      ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String title, value; final IconData icon;
  const _StatCard(this.title, this.value, this.icon);
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(children: [Icon(icon), Text(title, maxLines: 1), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))])));
}

class DecisionsPage extends StatefulWidget {
  const DecisionsPage({super.key});
  @override
  State<DecisionsPage> createState() => _DecisionsPageState();
}

class _DecisionsPageState extends State<DecisionsPage> {
  final a = TextEditingController();
  final b = TextEditingController();
  final c = TextEditingController();
  final d = TextEditingController();
  String mode = 'ROI';
  String result = '';

  void calc() {
    final x = number(a.text), y = number(b.text), z = number(c.text), w = number(d.text);
    if (mode == 'ROI') {
      if (x == 0) result = 'La inversión inicial debe ser mayor que 0.';
      else result = 'ROI = ${((y - x) / x * 100).toStringAsFixed(2)}%';
    } else if (mode == 'Punto de equilibrio') {
      final contribution = y - z;
      if (contribution <= 0) result = 'El precio debe ser mayor que el costo variable.';
      else result = 'Punto de equilibrio = ${(x / contribution).ceil()} unidades';
    } else {
      const rate = 0.10;
      final npv = -x + y / pow(1 + rate, 1) + z / pow(1 + rate, 2) + w / pow(1 + rate, 3);
      result = 'VAN aproximado = ${money(npv)} (tasa 10%)';
    }
    setState(() {});
  }


  @override
  Widget build(BuildContext context) {
    final fields = mode == 'ROI'
        ? [('Inversión inicial', a), ('Valor final / retorno total', b)]
        : mode == 'Punto de equilibrio'
            ? [('Costos fijos', a), ('Precio unitario', b), ('Costo variable unitario', c)]
            : [('Inversión inicial', a), ('Flujo año 1', b), ('Flujo año 2', c), ('Flujo año 3', d)];
    return Scaffold(
      appBar: AppBar(title: const Text('Decisiones financieras')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(value: mode, decoration: const InputDecoration(labelText: 'Calculadora'), items: ['ROI','Punto de equilibrio','VAN simple'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) { setState(() { mode = v ?? mode; result = ''; }); }),
        const SizedBox(height: 8),
        ...fields.map((f) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: TextField(controller: f.$2, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: f.$1, border: const OutlineInputBorder())))),
        if (mode == 'VAN simple') const Text('Nota: esta primera versión usa una tasa fija del 10% para el ejemplo. Próxima versión: tasa editable.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: calc, icon: const Icon(Icons.calculate), label: const Text('Calcular')),
        if (result.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(result, style: Theme.of(context).textTheme.titleLarge))),
      ]),
    );
  }
}

class StudyLockPage extends StatefulWidget {
  const StudyLockPage({super.key});
  @override
  State<StudyLockPage> createState() => _StudyLockPageState();
}

class _StudyLockPageState extends State<StudyLockPage> {
  final topic = TextEditingController();
  final minutes = TextEditingController(text: '25');
  Timer? timer;
  int remaining = 0;
  bool active = false;
  bool paused = false;

  void start() {
    final m = max(1, number(minutes.text).round());
    remaining = m * 60;
    active = true; paused = false;
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!paused && remaining > 0) setState(() => remaining--);
      if (remaining <= 0) {
        timer?.cancel();
        setState(() => active = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sesión completada.')));
      }
    });
    setState(() {});
  }

  @override
  void dispose() { timer?.cancel(); topic.dispose(); minutes.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final mm = (remaining ~/ 60).toString().padLeft(2, '0');
    final ss = (remaining % 60).toString().padLeft(2, '0');
    return PopScope(
      canPop: !active,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && active) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Termina o detén la sesión antes de salir.')));
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Study Lock')),
        body: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (!active) ...[
            TextField(controller: topic, decoration: const InputDecoration(labelText: 'Tema de estudio', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextField(controller: minutes, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Minutos', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: start, icon: const Icon(Icons.play_arrow), label: const Text('Iniciar sesión')),
            const SizedBox(height: 12),
            const Text('Durante una sesión se bloquea el botón Atrás dentro de la app. Home/Recientes requieren modo kiosco de Android para bloquearse a nivel del sistema.'),
          ] else ...[
            Text(topic.text.isEmpty ? 'Sesión de estudio' : topic.text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
            const Spacer(),
            Text('$mm:$ss', textAlign: TextAlign.center, style: const TextStyle(fontSize: 72, fontWeight: FontWeight.bold)),
            const Spacer(),
            Row(children: [
              Expanded(child: FilledButton.tonal(onPressed: () => setState(() => paused = !paused), child: Text(paused ? 'Continuar' : 'Pausar'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton(onPressed: () { timer?.cancel(); setState(() { active = false; remaining = 0; }); }, child: const Text('Detener'))),
            ]),
          ],
        ])),
      ),
    );
  }
}

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});
  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  List<Map<String, dynamic>> tasks = [];
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { tasks = await Store.list('smart_tasks'); if (mounted) setState(() {}); }
  Future<void> _save() => Store.saveList('smart_tasks', tasks);

  Future<void> _addTask() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Nueva tarea'), content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'Tarea')), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Añadir'))]));
    if (ok == true && c.text.trim().isNotEmpty) {
      tasks.insert(0, {'id': DateTime.now().microsecondsSinceEpoch, 'title': c.text.trim(), 'done': false, 'subs': <dynamic>[]});
      await _save(); setState(() {});
    }
  }

  Future<void> _addSub(Map<String, dynamic> task) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Nueva subtarea'), content: TextField(controller: c, autofocus: true), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Añadir'))]));
    if (ok == true && c.text.trim().isNotEmpty) {
      final subs = (task['subs'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      subs.add({'title': c.text.trim(), 'done': false}); task['subs'] = subs; await _save(); setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Smart Tasks')),
    floatingActionButton: FloatingActionButton(onPressed: _addTask, child: const Icon(Icons.add)),
    body: tasks.isEmpty ? const Center(child: Text('No tienes tareas pendientes.')) : ListView.builder(padding: const EdgeInsets.all(10), itemCount: tasks.length, itemBuilder: (_, i) {
      final t = tasks[i];
      final subs = (t['subs'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      return Dismissible(
        key: ValueKey(t['id']),
        onDismissed: (_) async { tasks.removeAt(i); await _save(); setState(() {}); },
        background: Container(color: Colors.red),
        child: Card(child: ExpansionTile(
          leading: Checkbox(value: t['done'] == true, onChanged: (v) async { t['done'] = v ?? false; await _save(); setState(() {}); }),
          title: Text(t['title'], style: TextStyle(decoration: t['done'] == true ? TextDecoration.lineThrough : null)),
          trailing: IconButton(icon: const Icon(Icons.add), tooltip: 'Añadir subtarea', onPressed: () => _addSub(t)),
          children: [
            if (subs.isEmpty) const ListTile(title: Text('Sin subtareas')),
            ...List.generate(subs.length, (j) => CheckboxListTile(value: subs[j]['done'] == true, title: Text(subs[j]['title']), onChanged: (v) async { subs[j]['done'] = v ?? false; t['subs'] = subs; await _save(); setState(() {}); })),
          ],
        )),
      );
    }),
  );
}

class DailyBriefPage extends StatefulWidget {
  const DailyBriefPage({super.key});
  @override
  State<DailyBriefPage> createState() => _DailyBriefPageState();
}

class _DailyBriefPageState extends State<DailyBriefPage> {
  List<Map<String, dynamic>> sources = [];
  List<Map<String, dynamic>> articles = [];
  bool loading = false;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    sources = await Store.list('rss_sources');
    articles = await Store.list('rss_articles');
    if (mounted) setState(() {});
  }

  Future<void> _addSource() async {
    final name = TextEditingController(); final url = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Añadir RSS'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')), TextField(controller: url, decoration: const InputDecoration(labelText: 'URL del feed RSS'))]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Añadir'))]));
    final parsed = Uri.tryParse(url.text.trim());
    if (ok == true && parsed != null && parsed.hasScheme && parsed.host.isNotEmpty) {
      sources.add({'id': DateTime.now().microsecondsSinceEpoch, 'name': name.text.trim().isEmpty ? url.text.trim() : name.text.trim(), 'url': url.text.trim()});
      await Store.saveList('rss_sources', sources); setState(() {});
    }
  }

  Future<void> _refresh() async {
    if (sources.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Añade al menos una fuente RSS.'))); return;
    }
    setState(() => loading = true);
    final collected = <Map<String, dynamic>>[];
    for (final s in sources) {
      try {
        final r = await http.get(Uri.parse(s['url']), headers: {'User-Agent': 'PersonalSuite/1.0'}).timeout(const Duration(seconds: 15));
        if (r.statusCode < 200 || r.statusCode >= 300) continue;
        final doc = XmlDocument.parse(r.body);
        final nodes = [...doc.findAllElements('item'), ...doc.findAllElements('entry')];
        for (final n in nodes.take(30)) {
          String text(String tag) => n.findElements(tag).firstOrNull?.innerText.trim() ?? '';
          var link = text('link');
          if (link.isEmpty) link = n.findElements('link').firstOrNull?.getAttribute('href') ?? '';
          final title = text('title');
          final description = text('description').isNotEmpty ? text('description') : text('summary');
          if (title.isEmpty) continue;
          final plain = description.replaceAll(RegExp(r'<[^>]*>'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
          collected.add({'id': '${s['url']}|$title'.hashCode, 'source': s['name'], 'title': title, 'summary': plain.length > 260 ? '${plain.substring(0,260)}…' : plain, 'link': link, 'savedAt': DateTime.now().toIso8601String()});
        }
      } catch (_) {}
    }
    final unique = <String, Map<String, dynamic>>{};
    for (final a in [...collected, ...articles]) { unique[a['title'].toString().toLowerCase()] = a; }
    articles = unique.values.take(150).toList();
    await Store.saveList('rss_articles', articles);
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Daily Brief Offline'), actions: [IconButton(onPressed: _addSource, icon: const Icon(Icons.add_link)), IconButton(onPressed: loading ? null : _refresh, icon: const Icon(Icons.refresh))]),
    body: Column(children: [
      if (sources.isNotEmpty) SizedBox(height: 54, child: ListView.separated(padding: const EdgeInsets.all(8), scrollDirection: Axis.horizontal, itemCount: sources.length, separatorBuilder: (_,__) => const SizedBox(width: 6), itemBuilder: (_, i) => InputChip(label: Text(sources[i]['name']), onDeleted: () async { sources.removeAt(i); await Store.saveList('rss_sources', sources); setState(() {}); }))),
      if (loading) const LinearProgressIndicator(),
      Expanded(child: articles.isEmpty ? const Center(child: Text('Añade tus fuentes RSS y pulsa actualizar.\nLos artículos quedarán guardados para leerlos offline.', textAlign: TextAlign.center)) : ListView.builder(itemCount: articles.length, itemBuilder: (_, i) { final a = articles[i]; return Card(child: ListTile(title: Text(a['title']), subtitle: Text('${a['source']}\n${a['summary']}', maxLines: 4, overflow: TextOverflow.ellipsis), onTap: () async { final u = Uri.tryParse(a['link'] ?? ''); if (u != null && u.hasScheme) await launchUrl(u, mode: LaunchMode.externalApplication); })); })),
    ]),
  );
}

extension FirstOrNullXml on Iterable<XmlElement> { XmlElement? get firstOrNull => isEmpty ? null : first; }

class TravelHunterPage extends StatefulWidget {
  const TravelHunterPage({super.key});
  @override
  State<TravelHunterPage> createState() => _TravelHunterPageState();
}

class _TravelHunterPageState extends State<TravelHunterPage> {
  final from = TextEditingController(text: 'MIA');
  final to = TextEditingController(text: 'MAD');
  final date = TextEditingController(text: today());

  Future<void> _openGoogleFlights() async {
    final query = Uri.encodeComponent('Flights from ${from.text.trim()} to ${to.text.trim()} on ${date.text.trim()}');
    final uri = Uri.parse('https://www.google.com/travel/flights?q=$query');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _openSkyscanner() async {
    final uri = Uri.parse('https://www.skyscanner.com/transport/flights/${from.text.trim().toLowerCase()}/${to.text.trim().toLowerCase()}/');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Travel Hunter')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: from, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Origen (IATA)', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: to, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Destino (IATA)', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: date, decoration: const InputDecoration(labelText: 'Fecha YYYY-MM-DD', border: OutlineInputBorder())),
      const SizedBox(height: 16),
      FilledButton.icon(onPressed: _openGoogleFlights, icon: const Icon(Icons.flight), label: const Text('Buscar en Google Flights')),
      const SizedBox(height: 8),
      FilledButton.tonalIcon(onPressed: _openSkyscanner, icon: const Icon(Icons.travel_explore), label: const Text('Buscar en Skyscanner')),
      const SizedBox(height: 18),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('La búsqueda agregada dentro de la app requiere credenciales de proveedores como Skyscanner, Duffel o Amadeus. Esta versión ya permite buscar de inmediato mediante los proveedores web y deja el módulo preparado para conectar las APIs.'))),
    ]),
  );
}

class PriceScannerPage extends StatefulWidget {
  const PriceScannerPage({super.key});
  @override
  State<PriceScannerPage> createState() => _PriceScannerPageState();
}

class _PriceScannerPageState extends State<PriceScannerPage> {
  final picker = ImagePicker();
  final textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
  final manual = TextEditingController();
  String recognized = '';
  List<String> prices = [];
  bool busy = false;

  void _parse(String text) {
    final re = RegExp(r'(?:(?:USD|US\$|\$)\s*)?\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})(?:\s*(?:USD|US\$))?', caseSensitive: false);
    final values = re.allMatches(text).map((m) => m.group(0)!.trim()).toSet().toList();
    setState(() { recognized = text; prices = values; });
  }

  Future<void> _scan(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 90);
    if (x == null) return;
    setState(() => busy = true);
    try {
      final input = InputImage.fromFilePath(x.path);
      final result = await textRecognizer.processImage(input);
      _parse(result.text);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo leer la imagen: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { textRecognizer.close(); manual.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Price Scanner')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _scan(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Cámara'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.tonalIcon(onPressed: busy ? null : () => _scan(ImageSource.gallery), icon: const Icon(Icons.photo), label: const Text('Galería'))),
      ]),
      if (busy) const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator()),
      const SizedBox(height: 12),
      TextField(controller: manual, minLines: 3, maxLines: 6, decoration: const InputDecoration(labelText: 'O pega texto aquí', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      FilledButton.tonal(onPressed: () => _parse(manual.text), child: const Text('Extraer precios del texto')),
      const SizedBox(height: 16),
      Text('Precios detectados', style: Theme.of(context).textTheme.titleLarge),
      if (prices.isEmpty) const Text('Todavía no hay precios detectados.'),
      ...prices.map((p) => ListTile(leading: const Icon(Icons.attach_money), title: SelectableText(p))),
      if (recognized.isNotEmpty) ExpansionTile(title: const Text('Texto OCR completo'), children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText(recognized))]),
    ]),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int notes = 0, pending = 0, articles = 0;
  double income = 0, expense = 0;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final ns = await Store.list('memora_notes');
    final ts = await Store.list('smart_tasks');
    final ar = await Store.list('rss_articles');
    final mv = await Store.list('business_moves');
    notes = ns.length; pending = ts.where((e) => e['done'] != true).length; articles = ar.length;
    income = mv.where((e) => e['type'] == 'Ingreso').fold(0, (a,b) => a + number('${b['amount']}'));
    expense = mv.where((e) => e['type'] == 'Gasto').fold(0, (a,b) => a + number('${b['amount']}'));
    if (mounted) setState(() {});
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Personal Dashboard'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
    body: ListView(padding: const EdgeInsets.all(14), children: [
      Text('Hoy · ${today()}', style: Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height: 12),
      _Dash('Tareas pendientes', '$pending', Icons.task_alt),
      _Dash('Entradas en Memora', '$notes', Icons.auto_stories),
      _Dash('Noticias guardadas', '$articles', Icons.newspaper),
      _Dash('Ingresos', money(income), Icons.trending_up),
      _Dash('Gastos', money(expense), Icons.trending_down),
      _Dash('Resultado neto', money(income-expense), Icons.account_balance_wallet),
    ]),
  );
}

class _Dash extends StatelessWidget {
  final String label, value; final IconData icon;
  const _Dash(this.label, this.value, this.icon);
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, size: 34), title: Text(label), trailing: Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))));
}
