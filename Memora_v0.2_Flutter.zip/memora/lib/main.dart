import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

void main() => runApp(const MemoraApp());

class MemoraApp extends StatelessWidget {
  const MemoraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Memora',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6750A4)),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFF8F7FC),
        ),
        home: const MemoraHome(),
      );
}

class KnowledgeItem {
  KnowledgeItem({required this.title, required this.content, required this.created});
  final String title;
  final String content;
  final String created;
  Map<String, dynamic> toJson() => {'title': title, 'content': content, 'created': created};
  factory KnowledgeItem.fromJson(Map<String, dynamic> j) => KnowledgeItem(
      title: j['title'] ?? '', content: j['content'] ?? '', created: j['created'] ?? '');
}

class MemoraHome extends StatefulWidget {
  const MemoraHome({super.key});
  @override
  State<MemoraHome> createState() => _MemoraHomeState();
}

class _MemoraHomeState extends State<MemoraHome> {
  int page = 0;
  List<KnowledgeItem> items = [];
  final question = TextEditingController();
  String answer = 'Importa contenido y pregúntame sobre tu biblioteca.';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('knowledge') ?? [];
    if (mounted) setState(() => items = raw.map((e) => KnowledgeItem.fromJson(jsonDecode(e))).toList());
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('knowledge', items.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<void> _importText() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['txt', 'md', 'pdf']);
    if (result == null || result.files.single.path == null) return;
    final file = result.files.single;
    String text;
    if (file.extension?.toLowerCase() == 'pdf') {
      final document = PdfDocument(inputBytes: await File(file.path!).readAsBytes());
      text = PdfTextExtractor(document).extractText();
      document.dispose();
      if (text.trim().isEmpty) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Este PDF parece contener imágenes. El OCR se añadirá en la próxima actualización.')));
        return;
      }
    } else {
      text = await File(file.path!).readAsString();
    }
    setState(() => items.insert(0, KnowledgeItem(title: file.name, content: text, created: DateTime.now().toIso8601String())));
    await _save();
  }

  List<String> _sentences(String text) => text.replaceAll(RegExp(r'\s+'), ' ').trim().split(RegExp(r'(?<=[.!?])\s+')).where((s) => s.length > 25).toList();

  String _summary(String text) {
    final clean = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    final sentences = _sentences(clean);
    if (sentences.length <= 4) return sentences.join(' ');
    final frequency = <String, int>{};
    for (final word in clean.toLowerCase().split(RegExp(r'\W+')).where((w) => w.length > 4)) {
      frequency[word] = (frequency[word] ?? 0) + 1;
    }
    final ranked = sentences.asMap().entries.map((e) {
      final score = e.value.toLowerCase().split(RegExp(r'\W+')).fold<int>(0, (n, w) => n + (frequency[w] ?? 0));
      return (index: e.key, text: e.value, score: score);
    }).toList()..sort((a, b) => b.score.compareTo(a.score));
    final chosen = ranked.take(4).toList()..sort((a, b) => a.index.compareTo(b.index));
    return chosen.map((e) => e.text).join(' ');
  }

  void _ask() {
    final words = question.text.toLowerCase().split(RegExp(r'\W+')).where((w) => w.length > 3).toSet();
    final matches = <({KnowledgeItem item, int score})>[];
    for (final item in items) {
      final haystack = '${item.title} ${item.content}'.toLowerCase();
      final current = words.where(haystack.contains).length;
      if (current > 0) matches.add((item: item, score: current));
    }
    matches.sort((a, b) => b.score.compareTo(a.score));
    final selected = matches.take(3).toList();
    setState(() => answer = selected.isEmpty
        ? 'No encontré esa respuesta en tu biblioteca. Añade más material o reformula la pregunta.'
        : '${selected.map((m) => _summary(m.item.content)).join('\n\n')}\n\nFuentes: ${selected.map((m) => m.item.title).join(', ')}');
  }

  void _study(KnowledgeItem item) {
    final facts = _sentences(item.content).take(10).toList();
    int index = 0;
    bool revealed = false;
    showDialog(context: context, barrierDismissible: false, builder: (_) => StatefulBuilder(builder: (context, setLocal) {
      if (facts.isEmpty) return AlertDialog(title: const Text('Sin tarjetas'), content: const Text('Este documento no tiene suficiente texto.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cerrar'))]);
      final words = facts[index].split(' ');
      final cut = words.length > 7 ? words.take(7).join(' ') : 'Idea principal';
      return AlertDialog(
        title: Text('Tarjeta ${index + 1} de ${facts.length}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [Text('¿Qué explica esta idea?\n\n$cut…', style: const TextStyle(fontSize: 18)), if (revealed) ...[const Divider(height: 28), Text(facts[index])]]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Salir')),
          if (!revealed) FilledButton(onPressed: () => setLocal(() => revealed = true), child: const Text('Mostrar respuesta'))
          else FilledButton(onPressed: () { if (index + 1 >= facts.length) { Navigator.pop(context); } else { setLocal(() { index++; revealed = false; }); } }, child: Text(index + 1 >= facts.length ? 'Terminar' : 'Siguiente')),
        ],
      );
    }));
  }

  int _connectionCount(KnowledgeItem source) {
    final words = source.content.toLowerCase().split(RegExp(r'\W+')).where((w) => w.length > 6).toSet();
    return items.where((other) => other != source && words.where(other.content.toLowerCase().contains).length >= 3).length;
  }

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), _library(), _tutor(), _review(), _progress()];
    return Scaffold(
      appBar: AppBar(title: const Text('Memora', style: TextStyle(fontWeight: FontWeight.w800))),
      body: SafeArea(child: pages[page]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: page,
        onDestinationSelected: (v) => setState(() => page = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Inicio'),
          NavigationDestination(icon: Icon(Icons.library_books_outlined), label: 'Biblioteca'),
          NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), label: 'Tutor'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), label: 'Repasar'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Progreso'),
        ],
      ),
    );
  }

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Tu conocimiento, siempre contigo.', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Guarda, entiende y recuerda tus propios materiales.'),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: _importText, icon: const Icon(Icons.add), label: const Text('Importar PDF, TXT o Markdown')),
        const SizedBox(height: 18),
        Row(children: [Expanded(child: _metric('${items.length}', 'Documentos')), const SizedBox(width: 12), Expanded(child: _metric('${items.length * 3}', 'Ideas guardadas'))]),
        const SizedBox(height: 22),
        const Text('Añadidos recientemente', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ...items.take(3).map(_itemTile),
      ]);

  Widget _metric(String value, String label) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [Text(value, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), Text(label)])));

  Widget _library() => Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: Row(children: [const Expanded(child: Text('Mi biblioteca', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))), IconButton.filled(onPressed: _importText, icon: const Icon(Icons.add))])),
        Expanded(child: items.isEmpty ? const Center(child: Text('Aún no has importado contenido.')) : ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: items.map(_itemTile).toList())),
      ]);

  Widget _itemTile(KnowledgeItem item) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.description_outlined)),
        title: Text(item.title), subtitle: Text(_summary(item.content), maxLines: 2, overflow: TextOverflow.ellipsis),
        onTap: () => showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => DraggableScrollableSheet(expand: false, initialChildSize: .8, builder: (_, c) => ListView(controller: c, padding: const EdgeInsets.all(22), children: [Text(item.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 16), const Text('Resumen', style: TextStyle(fontWeight: FontWeight.bold)), Text(_summary(item.content)), const Divider(height: 32), Text(item.content)]))),
      ));

  Widget _tutor() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Tutor Memora', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const Text('Las respuestas se buscan en tus materiales y muestran la fuente.'),
        const SizedBox(height: 22),
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Text(answer))),
        const SizedBox(height: 12),
        TextField(controller: question, decoration: InputDecoration(hintText: 'Pregunta sobre tu biblioteca…', border: const OutlineInputBorder(), suffixIcon: IconButton(onPressed: _ask, icon: const Icon(Icons.send)))),
      ]);

  Widget _review() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Repaso inteligente', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        if (items.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('Importa un documento para crear repasos.')))
        else ...items.map((e) => Card(child: ListTile(leading: const Icon(Icons.style_outlined), title: Text(e.title), subtitle: Text('Tarjetas de repaso • ${_connectionCount(e)} conexiones'), trailing: const Icon(Icons.chevron_right), onTap: () => _study(e)))),
      ]);

  Widget _progress() => ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Tu progreso', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        _metric('${items.length}', 'Contenidos guardados'),
        _metric('${items.fold<int>(0, (n, e) => n + e.content.split(RegExp(r"\s+")).length)}', 'Palabras disponibles'),
        _metric('${items.fold<int>(0, (n, e) => n + _connectionCount(e)) ~/ 2}', 'Conexiones encontradas'),
        const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('PDF, resúmenes, búsqueda, tarjetas y biblioteca permanecen disponibles sin conexión.'))),
      ]);
}
