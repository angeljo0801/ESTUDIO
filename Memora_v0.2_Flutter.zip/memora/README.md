# Memora

Biblioteca personal offline para guardar, resumir, consultar y repasar conocimiento.

## Versión 0.2

- Importación y extracción de texto de PDF, TXT y Markdown.
- Resumen extractivo local que selecciona las ideas más relevantes.
- Biblioteca persistente sin conexión.
- Tutor que combina hasta tres documentos y muestra sus fuentes.
- Tarjetas automáticas de repaso.
- Detección de conexiones entre documentos.
- Progreso y estadísticas offline.
- Compilación automática de APK con GitHub Actions.

## Compilar desde el teléfono

1. Sube el contenido de esta carpeta a un repositorio nuevo de GitHub.
2. Abre **Actions** y selecciona **Compilar APK Memora**.
3. Pulsa **Run workflow**.
4. Al terminar, descarga el archivo **Memora-APK** desde **Artifacts**.

Los PDF que sean solamente imágenes requerirán OCR. La IA generativa y la sincronización necesitarán servicios opcionales; la biblioteca y las funciones incluidas funcionan sin conexión.
