import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const int kPhoneBridgePort = 11436;

final _phoneBridgeServer = _PhoneBridgeServer();
final _phoneBridgeClient = _PhoneBridgeClient();

class PhoneBridgeService {
  static Future<void> autoStart() async {
    final settings = await _BridgeSettings.load();
    if (!settings.hostEnabled || settings.rootPath.isEmpty) return;
    final root = Directory(settings.rootPath);
    if (!await root.exists()) return;
    try {
      await _phoneBridgeServer.start(settings);
    } catch (_) {}
  }
}

class _BridgeSettings {
  static const _hostEnabledKey = 'phone_bridge_host_enabled';
  static const _rootPathKey = 'phone_bridge_root_path';
  static const _tokenKey = 'phone_bridge_token';
  static const _clientHostKey = 'phone_bridge_client_host';
  static const _clientTokenKey = 'phone_bridge_client_token';

  final bool hostEnabled;
  final String rootPath;
  final String token;
  final String clientHost;
  final String clientToken;

  const _BridgeSettings({
    required this.hostEnabled,
    required this.rootPath,
    required this.token,
    required this.clientHost,
    required this.clientToken,
  });

  static Future<_BridgeSettings> load() async {
    final p = await SharedPreferences.getInstance();
    var token = p.getString(_tokenKey) ?? '';
    if (token.isEmpty) {
      token = _newToken();
      await p.setString(_tokenKey, token);
    }
    return _BridgeSettings(
      hostEnabled: p.getBool(_hostEnabledKey) ?? false,
      rootPath: p.getString(_rootPathKey) ?? '',
      token: token,
      clientHost: p.getString(_clientHostKey) ?? '',
      clientToken: p.getString(_clientTokenKey) ?? '',
    );
  }

  static String _newToken() {
    final random = Random.secure();
    final bytes = List<int>.generate(24, (_) => random.nextInt(256));
    return base64UrlEncode(bytes).replaceAll('=', '');
  }

  static Future<String> rotateToken() async {
    final p = await SharedPreferences.getInstance();
    final token = _newToken();
    await p.setString(_tokenKey, token);
    return token;
  }

  static Future<void> setHostEnabled(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(_hostEnabledKey, value);
  }

  static Future<void> setRootPath(String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_rootPathKey, value);
  }

  static Future<void> setClient(String host, String token) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_clientHostKey, host);
    await p.setString(_clientTokenKey, token);
  }
}

class _PhoneBridgeServer {
  HttpServer? _server;
  StreamSubscription<HttpRequest>? _subscription;
  _BridgeSettings? _settings;
  String? lastError;

  bool get running => _server != null;

  Future<void> start(_BridgeSettings settings) async {
    final root = Directory(settings.rootPath);
    if (settings.rootPath.isEmpty || !await root.exists()) {
      throw StateError('La carpeta compartida ya no esta disponible.');
    }
    if (_server != null &&
        _settings?.rootPath == settings.rootPath &&
        _settings?.token == settings.token) {
      return;
    }
    await stop();
    try {
      final server = await HttpServer.bind(
        InternetAddress.anyIPv4,
        kPhoneBridgePort,
        shared: true,
      );
      _server = server;
      _settings = settings;
      _subscription = server.listen(
        _handle,
        onError: (Object error) => lastError = error.toString(),
        onDone: () {
          _server = null;
          _subscription = null;
        },
        cancelOnError: false,
      );
      lastError = null;
    } catch (e) {
      _server = null;
      _subscription = null;
      _settings = null;
      lastError = e.toString();
      rethrow;
    }
  }

  Future<void> stop() async {
    try {
      await _subscription?.cancel();
    } catch (_) {}
    _subscription = null;
    try {
      await _server?.close(force: true);
    } catch (_) {}
    _server = null;
    _settings = null;
  }

  Future<void> _handle(HttpRequest request) async {
    try {
      _cors(request.response);
      if (request.method == 'OPTIONS') {
        request.response.statusCode = HttpStatus.noContent;
        await request.response.close();
        return;
      }

      final settings = _settings;
      if (settings == null) {
        await _jsonError(request.response, HttpStatus.serviceUnavailable,
            'El puente no esta listo.');
        return;
      }
      if (!_authorized(request, settings.token)) {
        await _jsonError(
            request.response, HttpStatus.unauthorized, 'Token incorrecto.');
        return;
      }

      final path = request.uri.path;
      if (request.method == 'GET' && path == '/bridge/health') {
        await _json(request.response, {
          'ok': true,
          'name': 'Local AI Manager Phone Bridge',
          'version': 1,
          'port': kPhoneBridgePort,
        });
        return;
      }

      if (request.method == 'GET' && path == '/bridge/files') {
        await _handleList(request, settings);
        return;
      }
      if (request.method == 'GET' && path == '/bridge/download') {
        await _handleDownload(request, settings);
        return;
      }
      if (request.method == 'POST' && path == '/bridge/upload') {
        await _handleUpload(request, settings);
        return;
      }
      if (request.method == 'DELETE' && path == '/bridge/file') {
        await _handleDelete(request, settings);
        return;
      }

      await _jsonError(request.response, HttpStatus.notFound, 'No encontrado.');
    } catch (e) {
      try {
        await _jsonError(
            request.response, HttpStatus.internalServerError, e.toString());
      } catch (_) {}
    }
  }

  bool _authorized(HttpRequest request, String token) {
    final auth = request.headers.value(HttpHeaders.authorizationHeader) ?? '';
    return auth == 'Bearer $token';
  }

  void _cors(HttpResponse response) {
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set(
      'Access-Control-Allow-Headers',
      'Authorization, Content-Type',
    );
    response.headers.set(
      'Access-Control-Allow-Methods',
      'GET, POST, DELETE, OPTIONS',
    );
  }

  Future<void> _handleList(
    HttpRequest request,
    _BridgeSettings settings,
  ) async {
    final relative = request.uri.queryParameters['path'] ?? '';
    final dir = await _safeDirectory(settings.rootPath, relative);
    if (!await dir.exists()) {
      await _jsonError(request.response, HttpStatus.notFound,
          'La carpeta no existe.');
      return;
    }

    final items = <Map<String, dynamic>>[];
    await for (final entity in dir.list(followLinks: false)) {
      if (entity is Link) continue;
      final stat = await entity.stat();
      if (stat.type == FileSystemEntityType.notFound) continue;
      items.add({
        'name': _baseName(entity.path),
        'type': entity is Directory ? 'directory' : 'file',
        'size': entity is File ? stat.size : 0,
        'modifiedMs': stat.modified.millisecondsSinceEpoch,
      });
    }
    items.sort((a, b) {
      final ad = a['type'] == 'directory';
      final bd = b['type'] == 'directory';
      if (ad != bd) return ad ? -1 : 1;
      return (a['name'] as String)
          .toLowerCase()
          .compareTo((b['name'] as String).toLowerCase());
    });

    await _json(request.response, {
      'ok': true,
      'path': _cleanRelative(relative),
      'items': items,
    });
  }

  Future<void> _handleDownload(
    HttpRequest request,
    _BridgeSettings settings,
  ) async {
    final relative = request.uri.queryParameters['path'] ?? '';
    final file = await _safeFile(settings.rootPath, relative);
    if (!await file.exists()) {
      await _jsonError(
          request.response, HttpStatus.notFound, 'El archivo no existe.');
      return;
    }
    final stat = await file.stat();
    if (stat.type != FileSystemEntityType.file) {
      await _jsonError(request.response, HttpStatus.badRequest,
          'La ruta no apunta a un archivo.');
      return;
    }

    final name = _baseName(file.path).replaceAll('"', '');
    request.response.statusCode = HttpStatus.ok;
    request.response.headers.contentType = ContentType.binary;
    request.response.headers.set(
      HttpHeaders.contentDispositionHeader,
      'attachment; filename="$name"',
    );
    request.response.contentLength = stat.size;
    await file.openRead().pipe(request.response);
  }

  Future<void> _handleUpload(
    HttpRequest request,
    _BridgeSettings settings,
  ) async {
    final relativeDir = request.uri.queryParameters['path'] ?? '';
    final requestedName = request.uri.queryParameters['name'] ?? '';
    final name = _safeName(requestedName);
    if (name.isEmpty) {
      await _jsonError(
          request.response, HttpStatus.badRequest, 'Nombre invalido.');
      return;
    }
    final dir = await _safeDirectory(settings.rootPath, relativeDir);
    if (!await dir.exists()) {
      await _jsonError(request.response, HttpStatus.notFound,
          'La carpeta de destino no existe.');
      return;
    }

    final target = File('${dir.path}${Platform.pathSeparator}$name');
    final canonicalParent = await dir.resolveSymbolicLinks();
    if (!_insideRoot(settings.rootPath, canonicalParent)) {
      await _jsonError(request.response, HttpStatus.forbidden,
          'Destino fuera de la carpeta compartida.');
      return;
    }

    final temp = File('${target.path}.bridge-part');
    if (await temp.exists()) await temp.delete();
    final sink = temp.openWrite();
    try {
      await request.pipe(sink);
      if (await target.exists()) await target.delete();
      await temp.rename(target.path);
    } catch (e) {
      try {
        await sink.close();
      } catch (_) {}
      if (await temp.exists()) await temp.delete();
      rethrow;
    }

    await _json(request.response, {
      'ok': true,
      'name': name,
      'size': await target.length(),
    });
  }

  Future<void> _handleDelete(
    HttpRequest request,
    _BridgeSettings settings,
  ) async {
    final relative = request.uri.queryParameters['path'] ?? '';
    final clean = _cleanRelative(relative);
    if (clean.isEmpty) {
      await _jsonError(request.response, HttpStatus.badRequest,
          'No se puede eliminar la carpeta raiz.');
      return;
    }
    final type = await FileSystemEntity.type(
      _join(settings.rootPath, clean),
      followLinks: false,
    );
    if (type == FileSystemEntityType.link) {
      await _jsonError(
          request.response, HttpStatus.forbidden, 'Enlaces no permitidos.');
      return;
    }
    if (type == FileSystemEntityType.file) {
      final file = await _safeFile(settings.rootPath, clean);
      await file.delete();
    } else if (type == FileSystemEntityType.directory) {
      final dir = await _safeDirectory(settings.rootPath, clean);
      if (await dir.list(followLinks: false).isNotEmpty) {
        await _jsonError(request.response, HttpStatus.conflict,
            'La carpeta no esta vacia.');
        return;
      }
      await dir.delete();
    } else {
      await _jsonError(
          request.response, HttpStatus.notFound, 'No existe.');
      return;
    }
    await _json(request.response, {'ok': true});
  }

  Future<Directory> _safeDirectory(String rootPath, String relative) async {
    final clean = _cleanRelative(relative);
    final root = Directory(rootPath);
    final canonicalRoot = await root.resolveSymbolicLinks();
    final candidate = Directory(_join(canonicalRoot, clean));
    if (!await candidate.exists()) return candidate;
    final canonical = await candidate.resolveSymbolicLinks();
    if (!_insideRoot(canonicalRoot, canonical)) {
      throw StateError('Ruta fuera de la carpeta compartida.');
    }
    return Directory(canonical);
  }

  Future<File> _safeFile(String rootPath, String relative) async {
    final clean = _cleanRelative(relative);
    if (clean.isEmpty) throw StateError('Ruta de archivo invalida.');
    final root = Directory(rootPath);
    final canonicalRoot = await root.resolveSymbolicLinks();
    final candidate = File(_join(canonicalRoot, clean));
    if (!await candidate.exists()) return candidate;
    final canonical = await candidate.resolveSymbolicLinks();
    if (!_insideRoot(canonicalRoot, canonical)) {
      throw StateError('Ruta fuera de la carpeta compartida.');
    }
    return File(canonical);
  }

  String _cleanRelative(String raw) {
    final normalized = raw.replaceAll('\\', '/').trim();
    final parts = normalized
        .split('/')
        .where((part) => part.isNotEmpty && part != '.')
        .toList();
    if (parts.any((part) => part == '..' || part.contains(':'))) {
      throw StateError('Ruta invalida.');
    }
    return parts.join('/');
  }

  String _safeName(String raw) {
    final name = raw.trim();
    if (name.isEmpty ||
        name == '.' ||
        name == '..' ||
        name.contains('/') ||
        name.contains('\\') ||
        name.contains(':')) {
      return '';
    }
    return name;
  }

  bool _insideRoot(String root, String candidate) {
    final separator = Platform.pathSeparator;
    final normalizedRoot = root.endsWith(separator) ? root : '$root$separator';
    return candidate == root || candidate.startsWith(normalizedRoot);
  }

  String _join(String root, String relative) {
    if (relative.isEmpty) return root;
    return '$root${Platform.pathSeparator}${relative.replaceAll('/', Platform.pathSeparator)}';
  }

  String _baseName(String path) {
    final normalized = path.replaceAll('\\', '/');
    final parts = normalized.split('/');
    return parts.isEmpty ? path : parts.last;
  }

  Future<void> _json(HttpResponse response, Map<String, dynamic> body) async {
    response.statusCode = HttpStatus.ok;
    response.headers.contentType = ContentType.json;
    response.write(jsonEncode(body));
    await response.close();
  }

  Future<void> _jsonError(
      HttpResponse response, int status, String message) async {
    response.statusCode = status;
    response.headers.contentType = ContentType.json;
    response.write(jsonEncode({'ok': false, 'error': message}));
    await response.close();
  }
}

class _PhoneBridgeClient {
  HttpClient _client() {
    final client = HttpClient();
    client.connectionTimeout = const Duration(seconds: 8);
    client.idleTimeout = const Duration(seconds: 20);
    return client;
  }

  Uri _uri(String host, String endpoint, [Map<String, String>? query]) {
    var raw = host.trim();
    if (!raw.startsWith('http://') && !raw.startsWith('https://')) {
      raw = 'http://$raw';
    }
    var base = Uri.parse(raw);
    if (!base.hasPort) {
      base = base.replace(port: kPhoneBridgePort);
    }
    return base.replace(path: endpoint, queryParameters: query);
  }

  Future<Map<String, dynamic>> health(String host, String token) async {
    return _jsonRequest('GET', _uri(host, '/bridge/health'), token);
  }

  Future<List<_BridgeEntry>> list(
      String host, String token, String path) async {
    final data = await _jsonRequest(
      'GET',
      _uri(host, '/bridge/files', {'path': path}),
      token,
    );
    final rawItems = (data['items'] as List?) ?? const [];
    return rawItems
        .whereType<Map>()
        .map((raw) => _BridgeEntry.fromJson(Map<String, dynamic>.from(raw)))
        .toList();
  }

  Future<File> download(
      String host, String token, String relativePath) async {
    final client = _client();
    try {
      final request = await client.getUrl(
        _uri(host, '/bridge/download', {'path': relativePath}),
      );
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw StateError(await _responseError(response));
      }
      final docs = await getApplicationDocumentsDirectory();
      final dir = Directory(
        '${docs.path}${Platform.pathSeparator}phone_bridge_downloads',
      );
      await dir.create(recursive: true);
      final name = _baseName(relativePath);
      final file = File(
        '${dir.path}${Platform.pathSeparator}${_uniqueName(dir, name)}',
      );
      final sink = file.openWrite();
      await response.pipe(sink);
      return file;
    } finally {
      client.close(force: true);
    }
  }

  Future<void> upload(
    String host,
    String token,
    String remoteDir,
    String localPath,
  ) async {
    final file = File(localPath);
    if (!await file.exists()) throw StateError('El archivo local no existe.');
    final client = _client();
    try {
      final request = await client.postUrl(
        _uri(host, '/bridge/upload', {
          'path': remoteDir,
          'name': _baseName(localPath),
        }),
      );
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      request.headers.contentType = ContentType.binary;
      request.contentLength = await file.length();
      await request.addStream(file.openRead());
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw StateError(await _responseError(response));
      }
      await response.drain<void>();
    } finally {
      client.close(force: true);
    }
  }

  Future<void> delete(
      String host, String token, String relativePath) async {
    await _jsonRequest(
      'DELETE',
      _uri(host, '/bridge/file', {'path': relativePath}),
      token,
    );
  }

  Future<Map<String, dynamic>> _jsonRequest(
      String method, Uri uri, String token) async {
    final client = _client();
    try {
      final request = await client.openUrl(method, uri);
      request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $token');
      final response = await request.close();
      final text = await utf8.decoder.bind(response).join();
      Map<String, dynamic> data = {};
      if (text.trim().isNotEmpty) {
        final decoded = jsonDecode(text);
        if (decoded is Map) data = Map<String, dynamic>.from(decoded);
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw StateError((data['error'] ?? 'Error ${response.statusCode}').toString());
      }
      return data;
    } finally {
      client.close(force: true);
    }
  }

  Future<String> _responseError(HttpClientResponse response) async {
    final text = await utf8.decoder.bind(response).join();
    try {
      final decoded = jsonDecode(text);
      if (decoded is Map && decoded['error'] != null) {
        return decoded['error'].toString();
      }
    } catch (_) {}
    return 'Error ${response.statusCode}';
  }

  String _uniqueName(Directory dir, String original) {
    if (!File('${dir.path}${Platform.pathSeparator}$original').existsSync()) {
      return original;
    }
    final dot = original.lastIndexOf('.');
    final stem = dot > 0 ? original.substring(0, dot) : original;
    final ext = dot > 0 ? original.substring(dot) : '';
    var i = 2;
    while (File('${dir.path}${Platform.pathSeparator}$stem ($i)$ext')
        .existsSync()) {
      i++;
    }
    return '$stem ($i)$ext';
  }

  String _baseName(String path) {
    final normalized = path.replaceAll('\\', '/');
    final parts = normalized.split('/');
    return parts.isEmpty ? path : parts.last;
  }
}

class _BridgeEntry {
  final String name;
  final bool directory;
  final int size;
  final int modifiedMs;

  const _BridgeEntry({
    required this.name,
    required this.directory,
    required this.size,
    required this.modifiedMs,
  });

  factory _BridgeEntry.fromJson(Map<String, dynamic> json) => _BridgeEntry(
        name: (json['name'] ?? '').toString(),
        directory: json['type'] == 'directory',
        size: (json['size'] as num?)?.toInt() ?? 0,
        modifiedMs: (json['modifiedMs'] as num?)?.toInt() ?? 0,
      );
}

class PhoneBridgePage extends StatefulWidget {
  const PhoneBridgePage({super.key});

  @override
  State<PhoneBridgePage> createState() => _PhoneBridgePageState();
}

class _PhoneBridgePageState extends State<PhoneBridgePage> {
  final _clientHost = TextEditingController();
  final _clientToken = TextEditingController();

  bool _loading = true;
  bool _busy = false;
  bool _hostEnabled = false;
  bool _connected = false;
  String _rootPath = '';
  String _hostToken = '';
  String _remotePath = '';
  String? _error;
  List<String> _addresses = const [];
  List<_BridgeEntry> _entries = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _clientHost.dispose();
    _clientToken.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final settings = await _BridgeSettings.load();
    final addresses = await _localAddresses();
    if (!mounted) return;
    _clientHost.text = settings.clientHost;
    _clientToken.text = settings.clientToken;
    setState(() {
      _hostEnabled = settings.hostEnabled;
      _rootPath = settings.rootPath;
      _hostToken = settings.token;
      _addresses = addresses;
      _loading = false;
      _error = _phoneBridgeServer.lastError;
    });
  }

  Future<List<String>> _localAddresses() async {
    final out = <String>{};
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final interface in interfaces) {
        for (final address in interface.addresses) {
          if (!address.isLoopback && address.address.isNotEmpty) {
            out.add(address.address);
          }
        }
      }
    } catch (_) {}
    final list = out.toList();
    list.sort((a, b) {
      final at = a.startsWith('100.');
      final bt = b.startsWith('100.');
      if (at != bt) return at ? -1 : 1;
      return a.compareTo(b);
    });
    return list;
  }

  Future<void> _chooseRoot() async {
    final path = await FilePicker.platform.getDirectoryPath(
      dialogTitle: 'Elegir carpeta para compartir',
    );
    if (path == null || path.trim().isEmpty) return;
    final dir = Directory(path);
    if (!await dir.exists()) {
      _show('Android no dio acceso utilizable a esa carpeta. Elige otra.');
      return;
    }
    try {
      await dir.list(followLinks: false).take(1).toList();
    } catch (e) {
      _show('No puedo leer esa carpeta: $e');
      return;
    }
    await _BridgeSettings.setRootPath(path);
    if (!mounted) return;
    setState(() => _rootPath = path);
    if (_hostEnabled) await _restartHost();
  }

  Future<void> _toggleHost(bool value) async {
    if (value && _rootPath.isEmpty) {
      await _chooseRoot();
      if (_rootPath.isEmpty) return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _BridgeSettings.setHostEnabled(value);
      if (value) {
        final settings = await _BridgeSettings.load();
        await _phoneBridgeServer.start(settings);
      } else {
        await _phoneBridgeServer.stop();
      }
      final addresses = await _localAddresses();
      if (!mounted) return;
      setState(() {
        _hostEnabled = value;
        _addresses = addresses;
      });
    } catch (e) {
      await _BridgeSettings.setHostEnabled(false);
      if (!mounted) return;
      setState(() {
        _hostEnabled = false;
        _error = e.toString();
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restartHost() async {
    if (!_hostEnabled) return;
    try {
      await _phoneBridgeServer.start(await _BridgeSettings.load());
      if (mounted) setState(() => _error = null);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _rotateToken() async {
    final token = await _BridgeSettings.rotateToken();
    if (!mounted) return;
    setState(() => _hostToken = token);
    await _restartHost();
  }

  Future<void> _connect() async {
    final host = _clientHost.text.trim();
    final token = _clientToken.text.trim();
    if (host.isEmpty || token.isEmpty) {
      _show('Escribe la direccion y el token del otro telefono.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await _phoneBridgeClient.health(host, token);
      await _BridgeSettings.setClient(host, token);
      _remotePath = '';
      final entries = await _phoneBridgeClient.list(host, token, '');
      if (!mounted) return;
      setState(() {
        _connected = true;
        _entries = entries;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _connected = false;
        _entries = const [];
        _error = e.toString();
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refreshRemote() async {
    if (!_connected) return;
    setState(() => _busy = true);
    try {
      final entries = await _phoneBridgeClient.list(
        _clientHost.text.trim(),
        _clientToken.text.trim(),
        _remotePath,
      );
      if (mounted) setState(() => _entries = entries);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openEntry(_BridgeEntry entry) async {
    final fullPath = _appendRemote(_remotePath, entry.name);
    if (entry.directory) {
      setState(() => _remotePath = fullPath);
      await _refreshRemote();
      return;
    }
    setState(() => _busy = true);
    try {
      final file = await _phoneBridgeClient.download(
        _clientHost.text.trim(),
        _clientToken.text.trim(),
        fullPath,
      );
      _show('Descargado en Local Manager: ${file.path}');
    } catch (e) {
      _show('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _goUp() async {
    if (_remotePath.isEmpty) return;
    final parts = _remotePath.split('/')..removeLast();
    setState(() => _remotePath = parts.join('/'));
    await _refreshRemote();
  }

  Future<void> _upload() async {
    if (!_connected) return;
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      withData: false,
    );
    final path = result?.files.single.path;
    if (path == null || path.isEmpty) return;
    setState(() => _busy = true);
    try {
      await _phoneBridgeClient.upload(
        _clientHost.text.trim(),
        _clientToken.text.trim(),
        _remotePath,
        path,
      );
      await _refreshRemote();
      _show('Archivo enviado.');
    } catch (e) {
      _show('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete(_BridgeEntry entry) async {
    final fullPath = _appendRemote(_remotePath, entry.name);
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Eliminar del otro telefono'),
            content: Text('Eliminar ${entry.name}?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancelar'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Eliminar'),
              ),
            ],
          ),
        ) ??
        false;
    if (!confirmed) return;
    setState(() => _busy = true);
    try {
      await _phoneBridgeClient.delete(
        _clientHost.text.trim(),
        _clientToken.text.trim(),
        fullPath,
      );
      await _refreshRemote();
    } catch (e) {
      _show('$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _appendRemote(String base, String name) =>
      base.isEmpty ? name : '$base/$name';

  void _show(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    final kb = bytes / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    final mb = kb / 1024;
    if (mb < 1024) return '${mb.toStringAsFixed(1)} MB';
    return '${(mb / 1024).toStringAsFixed(2)} GB';
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Puente de archivos')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Este telefono como Host',
                      style: theme.textTheme.titleLarge),
                  const SizedBox(height: 6),
                  const Text(
                    'Comparte solo la carpeta que elijas. El modelo de IA no se carga para usar el puente.',
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: _hostEnabled,
                    onChanged: _busy ? null : _toggleHost,
                    title: const Text('Activar puente'),
                    subtitle: Text(
                      _phoneBridgeServer.running
                          ? 'Escuchando en el puerto $kPhoneBridgePort'
                          : 'Detenido',
                    ),
                  ),
                  const SizedBox(height: 4),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.folder_outlined),
                    title: const Text('Carpeta compartida'),
                    subtitle: Text(
                      _rootPath.isEmpty ? 'No seleccionada' : _rootPath,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: TextButton(
                      onPressed: _busy ? null : _chooseRoot,
                      child: const Text('Elegir'),
                    ),
                  ),
                  const Divider(),
                  const Text('Direcciones de este telefono'),
                  const SizedBox(height: 4),
                  if (_addresses.isEmpty)
                    const Text('No encontre una direccion IPv4 disponible.')
                  else
                    for (final address in _addresses)
                      SelectableText('http://$address:$kPhoneBridgePort'),
                  const SizedBox(height: 8),
                  Text(
                    'En la misma Wi-Fi usa una direccion local. Por Internet puedes usar la direccion privada de Tailscale (normalmente 100.x.x.x).',
                    style: theme.textTheme.bodySmall,
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Expanded(child: Text('Token de emparejamiento')),
                      IconButton(
                        tooltip: 'Copiar token',
                        onPressed: () async {
                          await Clipboard.setData(
                            ClipboardData(text: _hostToken),
                          );
                          _show('Token copiado.');
                        },
                        icon: const Icon(Icons.copy),
                      ),
                      IconButton(
                        tooltip: 'Crear token nuevo',
                        onPressed: _busy ? null : _rotateToken,
                        icon: const Icon(Icons.refresh),
                      ),
                    ],
                  ),
                  SelectableText(_hostToken),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Conectarse a otro telefono',
                      style: theme.textTheme.titleLarge),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _clientHost,
                    keyboardType: TextInputType.url,
                    decoration: const InputDecoration(
                      labelText: 'Direccion del Host',
                      hintText: '192.168.1.50 o 100.x.x.x',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _clientToken,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Token',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.icon(
                        onPressed: _busy ? null : _connect,
                        icon: const Icon(Icons.link),
                        label: Text(_connected ? 'Reconectar' : 'Conectar'),
                      ),
                      OutlinedButton.icon(
                        onPressed: !_connected || _busy ? null : _refreshRemote,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Actualizar'),
                      ),
                      OutlinedButton.icon(
                        onPressed: !_connected || _busy ? null : _upload,
                        icon: const Icon(Icons.upload_file),
                        label: const Text('Enviar archivo'),
                      ),
                    ],
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 10),
                    Text(
                      _error!,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                  ],
                ],
              ),
            ),
          ),
          if (_connected) ...[
            const SizedBox(height: 12),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: IconButton(
                      tooltip: 'Subir un nivel',
                      onPressed:
                          _remotePath.isEmpty || _busy ? null : _goUp,
                      icon: const Icon(Icons.arrow_upward),
                    ),
                    title: const Text('Archivos remotos'),
                    subtitle: Text(
                      _remotePath.isEmpty ? '/' : '/$_remotePath',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  const Divider(height: 1),
                  if (_entries.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text('Carpeta vacia.'),
                    )
                  else
                    for (final entry in _entries)
                      ListTile(
                        leading: Icon(
                          entry.directory
                              ? Icons.folder
                              : Icons.insert_drive_file_outlined,
                        ),
                        title: Text(entry.name),
                        subtitle: entry.directory
                            ? const Text('Carpeta')
                            : Text(_formatBytes(entry.size)),
                        onTap: _busy ? null : () => _openEntry(entry),
                        trailing: IconButton(
                          tooltip: 'Eliminar',
                          onPressed: _busy ? null : () => _delete(entry),
                          icon: const Icon(Icons.delete_outline),
                        ),
                      ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Como enlazar dos telefonos',
                      style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  const Text(
                    '1. En el telefono que tiene los archivos, activa Host y elige la carpeta.\n'
                    '2. Copia una de sus direcciones y el token.\n'
                    '3. En el segundo telefono abre Local Manager, pega direccion y token y toca Conectar.\n'
                    '4. Fuera de la misma Wi-Fi, conecta ambos a la misma red privada de Tailscale y usa la direccion 100.x.x.x del Host.',
                  ),
                ],
              ),
            ),
          ),
          if (_busy) ...[
            const SizedBox(height: 16),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }
}
