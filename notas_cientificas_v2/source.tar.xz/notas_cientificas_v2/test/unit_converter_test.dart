import 'package:flutter_test/flutter_test.dart';
import 'package:notas_cientificas/unit_converter.dart';

void main() {
  test('conversión de libras y kilogramos', () {
    expect(convertUnit('Peso', 'Libras', 'Kilogramos', 1), closeTo(0.45359237, 1e-9));
  });
  test('conversión de temperatura', () {
    expect(convertUnit('Temperatura', 'Celsius', 'Fahrenheit', 100), closeTo(212, 1e-9));
  });
  test('conversión de kilómetros y millas', () {
    expect(convertUnit('Longitud', 'Millas', 'Kilómetros', 1), closeTo(1.609344, 1e-9));
  });
}
