import 'package:flutter_test/flutter_test.dart';
import 'package:notas_cientificas/calculator_engine.dart';

void main() {
  const engine = CalculatorEngine();
  test('prioridad de operadores', () {
    expect(engine.calculate('2+3×4'), '14');
    expect(engine.calculate('(2+3)×4'), '20');
  });
  test('funciones científicas', () {
    expect(engine.calculate('sin(30)'), '0.5');
    expect(engine.calculate('√(81)'), '9');
    expect(engine.calculate('5!'), '120');
    expect(engine.calculate('2^3^2'), '512');
    expect(engine.calculate('200+10%'), '220');
  });
  test('multiplicación implícita y grados', () {
    expect(engine.calculate('2(3+4)'), '14');
    expect(engine.calculate('cos(60)'), '0.5');
  });
  test('división por cero', () {
    expect(() => engine.evaluate('3/0'), throwsFormatException);
  });
}
