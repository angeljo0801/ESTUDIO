import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:notas_cientificas/main.dart';
import 'package:notas_cientificas/storage.dart';

void main() {
  testWidgets('Muestra las pestañas de notas y calculadora', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final store = await LocalStore.open();
    await tester.pumpWidget(NotesCalculatorApp(store: store));
    expect(find.text('Mis notas'), findsOneWidget);
    await tester.tap(find.byIcon(Icons.calculate_outlined).first);
    await tester.pumpAndSettle();
    expect(find.text('Calculadora'), findsWidgets);
  });
}
