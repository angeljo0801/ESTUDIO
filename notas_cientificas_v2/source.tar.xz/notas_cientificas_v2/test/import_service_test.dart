import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:notas_cientificas/import_service.dart';
import 'package:notas_cientificas/models.dart';

void main() {
  test('Importa texto plano desde bytes', () async {
    final imported = await ImportService.importBytes(
      utf8.encode('Uno\nDos'), name: 'clase.txt');
    expect(imported.title, 'clase');
    expect(imported.content, 'Uno\nDos');
    expect(imported.pdfPath, isNull);
  });

  test('Importa intercambio NCNOTE v1', () async {
    final imported = await ImportService.importBytes(utf8.encode(jsonEncode({
      'format': 'notas-cientificas', 'version': 1,
      'title': 'Apuntes', 'folder': 'Clases',
      'tags': ['redes'], 'content': 'TCP/IP',
    })), name: 'nota.ncnote');
    expect(imported.title, 'Apuntes');
    expect(imported.folder, 'Clases');
    expect(imported.tags, ['redes']);
    expect(imported.content, 'TCP/IP');
  });

  test('Rechaza esquema NCNOTE desconocido', () async {
    expect(() => ImportService.importBytes(
      utf8.encode('{"format":"otro","version":1}'), name: 'nota.ncnote'),
      throwsFormatException);
  });

  test('Lee notas antiguas de v0.1 sin perder datos', () {
    final note = Note.fromJson({
      'id': '1', 'title': 'Antigua', 'content': 'Apuntes',
      'createdAt': '2026-01-01T08:00:00.000',
      'updatedAt': '2026-01-01T08:00:00.000',
      'pinned': true,
    });
    expect(note.title, 'Antigua');
    expect(note.pinned, true);
    expect(note.trashed, false);
    expect(note.inkData, isNull);
    expect(Note.fromJson(note.toJson()).id, '1');
  });
}
