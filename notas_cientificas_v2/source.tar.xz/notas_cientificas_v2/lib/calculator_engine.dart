import 'dart:math' as math;

/// Motor matemático local: no utiliza eval ni conexión a internet.
/// Incluye precedencia, paréntesis, potencias, trigonometría y funciones.
class CalculatorEngine {
  const CalculatorEngine();

  double evaluate(String input, {bool radians = false}) {
    final normalized = input
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('π', 'pi')
        .replaceAll('√', 'sqrt');
    final parser = _Parser(_tokenize(normalized), radians);
    final value = parser.parse();
    if (value.isNaN || value.isInfinite) {
      throw const FormatException('Resultado fuera de rango');
    }
    return value;
  }

  String calculate(String input, {bool radians = false}) =>
      format(evaluate(input, radians: radians));

  static String format(double value) {
    if (value.abs() < 1e-12) value = 0;
    if (value == value.truncateToDouble() && value.abs() < 1e15) {
      return value.toInt().toString();
    }
    final rounded = value.toStringAsPrecision(12);
    if (rounded.contains('e') || rounded.contains('E')) return rounded;
    return rounded.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
}

class _Token {
  final String text;
  const _Token(this.text);
}

List<_Token> _tokenize(String source) {
  final input = source.replaceAll(RegExp(r'\s+'), '');
  final raw = <_Token>[];
  var i = 0;
  while (i < input.length) {
    final rest = input.substring(i);
    final matchNumber = RegExp(r'^(?:\d+(?:\.\d*)?|\.\d+)').firstMatch(rest);
    if (matchNumber != null) {
      raw.add(_Token(matchNumber.group(0)!));
      i += matchNumber.group(0)!.length;
      continue;
    }
    final matchName = RegExp(r'^[A-Za-z]+').firstMatch(rest);
    if (matchName != null) {
      raw.add(_Token(matchName.group(0)!.toLowerCase()));
      i += matchName.group(0)!.length;
      continue;
    }
    final character = input[i];
    if ('+-*/^()%!'.contains(character)) {
      raw.add(_Token(character));
      i++;
      continue;
    }
    throw FormatException('Carácter no válido: $character');
  }
  // Multiplicación implícita: 2π, 2(3), (2)(3), π(2).
  final tokens = <_Token>[];
  const functions = {
    'sin', 'cos', 'tan', 'asin', 'acos', 'atan',
    'ln', 'log', 'sqrt', 'abs', 'exp',
  };
  for (final token in raw) {
    if (tokens.isNotEmpty) {
      final previous = tokens.last.text;
      final current = token.text;
      final previousEnd = previous == ')' || previous == '!' ||
          previous == '%' || previous == 'pi' || previous == 'e' ||
          double.tryParse(previous) != null;
      final nextStart = current == '(' || current == 'pi' ||
          current == 'e' || functions.contains(current) ||
          double.tryParse(current) != null;
      if (previousEnd && nextStart && !(functions.contains(previous))) {
        tokens.add(const _Token('*'));
      }
    }
    tokens.add(token);
  }
  tokens.add(const _Token('#'));
  return tokens;
}

class _Parser {
  final List<_Token> tokens;
  final bool radians;
  int position = 0;

  _Parser(this.tokens, this.radians);

  String get current => tokens[position].text;

  bool accept(String token) {
    if (current != token) return false;
    position++;
    return true;
  }

  void expect(String token) {
    if (!accept(token)) throw FormatException('Se esperaba $token');
  }

  double parse() {
    if (current == '#') throw const FormatException('Operación vacía');
    final result = _sum();
    expect('#');
    return result;
  }

  double _sum() {
    var value = _product();
    while (current == '+' || current == '-') {
      final op = current;
      position++;
      final right = _product();
      // Para suma/resta, 200 + 10% se interpreta como 200 + (200 * 0.1).
      // Las operaciones de porcentaje más complejas siguen el orden algebraico.
      final isRelativePercentage = position > 0 && tokens[position - 1].text == '%';
      final adjustedRight = isRelativePercentage ? value * right : right;
      value = op == '+' ? value + adjustedRight : value - adjustedRight;
    }
    return value;
  }

  double _product() {
    var value = _unary();
    while (current == '*' || current == '/') {
      final op = current;
      position++;
      final right = _unary();
      if (op == '/' && right == 0) throw const FormatException('División por cero');
      value = op == '*' ? value * right : value / right;
    }
    return value;
  }

  double _unary() {
    if (accept('+')) return _unary();
    if (accept('-')) return -_unary();
    return _power();
  }

  double _power() {
    final value = _postfix();
    if (accept('^')) return math.pow(value, _unary()).toDouble();
    return value;
  }

  double _postfix() {
    var value = _primary();
    while (current == '!' || current == '%') {
      if (accept('%')) {
        value /= 100;
      } else if (accept('!')) {
        if (value < 0 || value != value.floorToDouble() || value > 170) {
          throw const FormatException('Factorial requiere entero entre 0 y 170');
        }
        var result = 1.0;
        for (var n = 2; n <= value.toInt(); n++) result *= n;
        value = result;
      }
    }
    return value;
  }

  double _primary() {
    if (accept('(')) {
      final value = _sum();
      expect(')');
      return value;
    }
    if (accept('pi')) return math.pi;
    if (accept('e')) return math.e;
    const functions = {
      'sin', 'cos', 'tan', 'asin', 'acos', 'atan',
      'ln', 'log', 'sqrt', 'abs', 'exp',
    };
    if (functions.contains(current)) {
      final name = current;
      position++;
      expect('(');
      final x = _sum();
      expect(')');
      final toRadians = radians ? x : x * math.pi / 180;
      final fromRadians = radians ? 1.0 : 180 / math.pi;
      switch (name) {
        case 'sin': return math.sin(toRadians);
        case 'cos': return math.cos(toRadians);
        case 'tan': return math.tan(toRadians);
        case 'asin': return math.asin(x) * fromRadians;
        case 'acos': return math.acos(x) * fromRadians;
        case 'atan': return math.atan(x) * fromRadians;
        case 'ln': return math.log(x);
        case 'log': return math.log(x) / math.ln10;
        case 'sqrt': return math.sqrt(x);
        case 'abs': return x.abs();
        case 'exp': return math.exp(x);
      }
    }
    final number = double.tryParse(current);
    if (number != null) {
      position++;
      return number;
    }
    throw FormatException('Expresión incompleta cerca de $current');
  }
}
