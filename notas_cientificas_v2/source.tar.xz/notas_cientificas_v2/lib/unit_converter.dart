import 'package:flutter/material.dart';
import 'calculator_engine.dart';

/// Los factores convierten a la unidad base de cada categoría.
const unitGroups = <String, Map<String, double>>{
  'Longitud': {'Metros': 1, 'Kilómetros': 1000, 'Centímetros': 0.01,
    'Milímetros': 0.001, 'Pulgadas': 0.0254, 'Pies': 0.3048,
    'Yardas': 0.9144, 'Millas': 1609.344},
  'Peso': {'Kilogramos': 1, 'Gramos': 0.001, 'Libras': 0.45359237,
    'Onzas': 0.028349523125, 'Toneladas': 1000},
  'Área': {'Metros cuadrados': 1, 'Kilómetros cuadrados': 1000000,
    'Pies cuadrados': 0.09290304, 'Pulgadas cuadradas': 0.00064516,
    'Hectáreas': 10000, 'Acres': 4046.8564224},
  'Volumen': {'Litros': 1, 'Mililitros': 0.001, 'Galones (EE. UU.)': 3.785411784,
    'Pintas (EE. UU.)': 0.473176473, 'Metros cúbicos': 1000},
  'Velocidad': {'m/s': 1, 'km/h': 1 / 3.6, 'mph': 0.44704, 'Nudos': 0.514444444},
  'Tiempo': {'Segundos': 1, 'Minutos': 60, 'Horas': 3600,
    'Días': 86400, 'Semanas': 604800},
  'Datos': {'Bytes': 1, 'Kilobytes': 1000, 'Megabytes': 1000000,
    'Gigabytes': 1000000000, 'Kibibytes': 1024,
    'Mebibytes': 1048576, 'Gibibytes': 1073741824},
  'Temperatura': {'Celsius': 1, 'Fahrenheit': 1, 'Kelvin': 1},
};

double convertUnit(String group, String from, String to, double value) {
  if (group == 'Temperatura') {
    final celsius = switch (from) {
      'Fahrenheit' => (value - 32) * 5 / 9,
      'Kelvin' => value - 273.15,
      _ => value,
    };
    return switch (to) {
      'Fahrenheit' => celsius * 9 / 5 + 32,
      'Kelvin' => celsius + 273.15,
      _ => celsius,
    };
  }
  final units = unitGroups[group]!;
  return value * units[from]! / units[to]!;
}

class UnitConverterSheet extends StatefulWidget {
  const UnitConverterSheet({super.key});
  @override
  State<UnitConverterSheet> createState() => _UnitConverterSheetState();
}

class _UnitConverterSheetState extends State<UnitConverterSheet> {
  String group = 'Longitud';
  String from = 'Metros';
  String to = 'Kilómetros';
  final input = TextEditingController(text: '1');

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final units = unitGroups[group]!.keys.toList();
    final number = double.tryParse(input.text.replaceAll(',', '.'));
    final result = number == null ? null : convertUnit(group, from, to, number);
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.only(left: 20, right: 20, top: 12,
          bottom: 20 + MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(child: Container(height: 4, width: 44,
              decoration: BoxDecoration(color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(8)))),
            const SizedBox(height: 18),
            Text('Conversor de unidades', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: group,
              decoration: const InputDecoration(labelText: 'Categoría', border: OutlineInputBorder()),
              items: unitGroups.keys.map((name) => DropdownMenuItem(value: name, child: Text(name))).toList(),
              onChanged: (newGroup) {
                if (newGroup == null) return;
                setState(() {
                  group = newGroup;
                  final keys = unitGroups[group]!.keys.toList();
                  from = keys[0];
                  to = keys[1];
                });
              },
            ),
            const SizedBox(height: 14),
            TextField(controller: input, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
              decoration: const InputDecoration(labelText: 'Cantidad', border: OutlineInputBorder()),
              onChanged: (_) => setState(() {})),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              key: ValueKey('from-$group'), value: from,
              decoration: const InputDecoration(labelText: 'Desde', border: OutlineInputBorder()),
              items: units.map((name) => DropdownMenuItem(value: name, child: Text(name))).toList(),
              onChanged: (value) => setState(() => from = value ?? from),
            ),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              key: ValueKey('to-$group'), value: to,
              decoration: const InputDecoration(labelText: 'Hasta', border: OutlineInputBorder()),
              items: units.map((name) => DropdownMenuItem(value: name, child: Text(name))).toList(),
              onChanged: (value) => setState(() => to = value ?? to),
            ),
            const SizedBox(height: 20),
            Text(result == null ? 'Introduce un número válido' : CalculatorEngine.format(result),
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
          ]),
        ),
      ),
    );
  }
}
