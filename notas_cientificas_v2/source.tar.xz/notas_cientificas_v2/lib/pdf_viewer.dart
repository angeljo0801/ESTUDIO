import 'dart:io';

import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';

/// Conserva el PDF original para lectura y zoom. Las notas manuscritas se
/// guardan por separado en el lienzo de tinta de la nota.
class AttachedPdfPage extends StatefulWidget {
  final String path;
  const AttachedPdfPage({super.key, required this.path});
  @override
  State<AttachedPdfPage> createState() => _AttachedPdfPageState();
}

class _AttachedPdfPageState extends State<AttachedPdfPage> {
  late final PdfControllerPinch controller = PdfControllerPinch(
    document: PdfDocument.openFile(widget.path));

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Documento original')),
      body: File(widget.path).existsSync()
        ? PdfViewPinch(controller: controller)
        : const Center(child: Text('Ya no se encuentra el PDF adjunto')));
  }
}
