import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class InkPoint {
  final double x;
  final double y;
  final double pressure;
  const InkPoint(this.x, this.y, this.pressure);
  Map<String, double> toJson() => {'x': x, 'y': y, 'p': pressure};
  factory InkPoint.fromJson(Map<String, dynamic> json) => InkPoint(
    (json['x'] as num).toDouble(), (json['y'] as num).toDouble(),
    (json['p'] as num?)?.toDouble() ?? 0.5);
}

class InkStroke {
  final List<InkPoint> points;
  final int color;
  final double width;
  final bool highlighter;
  const InkStroke({required this.points, required this.color,
    required this.width, this.highlighter = false});
  Map<String, dynamic> toJson() => {'points': points.map((e) => e.toJson()).toList(),
    'color': color, 'width': width, 'highlighter': highlighter};
  factory InkStroke.fromJson(Map<String, dynamic> json) => InkStroke(
    points: (json['points'] as List<dynamic>).map(
      (e) => InkPoint.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
    color: json['color'] as int,
    width: (json['width'] as num?)?.toDouble() ?? 2.5,
    highlighter: json['highlighter'] as bool? ?? false);
}

List<InkStroke> parseInk(String? json) {
  if (json == null || json.isEmpty) return [];
  try {
    return (jsonDecode(json) as List<dynamic>)
      .map((e) => InkStroke.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  } catch (_) { return []; }
}

/// Lienzo vectorial persistente; registra presión del S Pen si Flutter la expone.
/// Los trazos se guardan en coordenadas proporcionales para soportar rotación.
class InkCanvasPage extends StatefulWidget {
  final String? initialInk;
  const InkCanvasPage({super.key, this.initialInk});
  @override
  State<InkCanvasPage> createState() => _InkCanvasPageState();
}

class _InkCanvasPageState extends State<InkCanvasPage> {
  late List<InkStroke> strokes = parseInk(widget.initialInk);
  final List<InkStroke> undone = [];
  final List<InkPoint> activePoints = [];
  int? activePointer;
  Color penColor = Colors.black;
  double penWidth = 2.6;
  bool highlighter = false;
  bool eraser = false;
  bool stylusOnly = true;
  Size canvasSize = Size.zero;

  double _pressure(PointerEvent event) {
    if (event.kind != PointerDeviceKind.stylus &&
        event.kind != PointerDeviceKind.invertedStylus) return 0.5;
    final span = event.pressureMax - event.pressureMin;
    if (span <= 0) return 0.5;
    return ((event.pressure - event.pressureMin) / span).clamp(0.1, 1);
  }

  InkPoint _point(PointerEvent event) => InkPoint(
    (event.localPosition.dx / math.max(1, canvasSize.width)).clamp(0, 1),
    (event.localPosition.dy / math.max(1, canvasSize.height)).clamp(0, 1),
    _pressure(event));

  bool _accept(PointerEvent event) {
    if (event.kind == PointerDeviceKind.stylus ||
        event.kind == PointerDeviceKind.invertedStylus) return true;
    return !stylusOnly && event.kind == PointerDeviceKind.touch;
  }

  void _start(PointerDownEvent event) {
    if (!_accept(event) || activePointer != null) return;
    activePointer = event.pointer;
    final point = _point(event);
    if (eraser || event.kind == PointerDeviceKind.invertedStylus) {
      _eraseNear(point);
      activePointer = null;
      return;
    }
    setState(() => activePoints.add(point));
  }

  void _move(PointerMoveEvent event) {
    if (event.pointer != activePointer) return;
    setState(() => activePoints.add(_point(event)));
  }

  void _end(PointerEvent event) {
    if (event.pointer != activePointer) return;
    if (activePoints.isNotEmpty) {
      setState(() {
        strokes.add(InkStroke(points: List.of(activePoints),
          color: penColor.toARGB32(), width: penWidth, highlighter: highlighter));
        activePoints.clear();
        undone.clear();
      });
    }
    activePointer = null;
  }

  void _eraseNear(InkPoint p) {
    // Borrador por trazo. No modifica el resto del dibujo.
    const thresholdSq = 0.00065;
    for (var i = strokes.length - 1; i >= 0; i--) {
      if (strokes[i].points.any((q) =>
        (p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y) < thresholdSq)) {
        setState(() { strokes.removeAt(i); undone.clear(); });
        break;
      }
    }
  }

  void _undo() {
    if (strokes.isEmpty) return;
    setState(() => undone.add(strokes.removeLast()));
  }

  void _redo() {
    if (undone.isEmpty) return;
    setState(() => strokes.add(undone.removeLast()));
  }

  void _finish() => Navigator.pop(context,
    jsonEncode(strokes.map((e) => e.toJson()).toList()));

  @override
  Widget build(BuildContext context) {
    final colors = [Colors.black, Colors.blue, Colors.red,
      Colors.green, Colors.purple, Colors.orange];
    return Scaffold(
      appBar: AppBar(title: const Text('Escribir con S Pen'), actions: [
        IconButton(onPressed: strokes.isEmpty ? null : _undo,
          tooltip: 'Deshacer', icon: const Icon(Icons.undo)),
        IconButton(onPressed: undone.isEmpty ? null : _redo,
          tooltip: 'Rehacer', icon: const Icon(Icons.redo)),
        TextButton(onPressed: _finish, child: const Text('Guardar')),
      ]),
      body: Column(children: [
        SizedBox(height: 65, child: ListView(scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 10), children: [
            IconButton.filledTonal(onPressed: () => setState(() {
              eraser = false; highlighter = false;
            }), tooltip: 'Bolígrafo', icon: const Icon(Icons.edit)),
            IconButton.filledTonal(onPressed: () => setState(() {
              eraser = false; highlighter = true;
            }), tooltip: 'Resaltador', icon: const Icon(Icons.border_color_outlined)),
            IconButton.filledTonal(onPressed: () => setState(() => eraser = !eraser),
              tooltip: 'Borrador por trazo', icon: const Icon(Icons.cleaning_services_outlined)),
            const VerticalDivider(width: 16),
            for (final color in colors)
              Padding(padding: const EdgeInsets.symmetric(horizontal: 4),
                child: InkWell(onTap: () => setState(() { penColor = color; eraser = false; }),
                  child: CircleAvatar(radius: penColor == color ? 16 : 13,
                    backgroundColor: color, child: penColor == color
                      ? const Icon(Icons.check, color: Colors.white, size: 17) : null))),
            const SizedBox(width: 8),
            PopupMenuButton<double>(tooltip: 'Grosor',
              icon: const Icon(Icons.line_weight),
              onSelected: (value) => setState(() => penWidth = value),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 1.4, child: Text('Fino')),
                PopupMenuItem(value: 2.6, child: Text('Medio')),
                PopupMenuItem(value: 5.0, child: Text('Grueso')),
              ]),
          ])),
        SwitchListTile.adaptive(
          dense: true, title: const Text('Solo S Pen (rechazar dedos)'),
          value: stylusOnly, onChanged: (v) => setState(() => stylusOnly = v)),
        Expanded(child: LayoutBuilder(builder: (context, constraints) {
          canvasSize = Size(constraints.maxWidth, constraints.maxHeight);
          return ColoredBox(color: Colors.white,
            child: Listener(
              behavior: HitTestBehavior.opaque,
              onPointerDown: _start, onPointerMove: _move,
              onPointerUp: _end, onPointerCancel: _end,
              child: CustomPaint(size: canvasSize,
                painter: _InkPainter(strokes, activePoints,
                  penColor: penColor, penWidth: penWidth, highlighter: highlighter)),
            ));
        })),
      ]),
    );
  }
}

class _InkPainter extends CustomPainter {
  final List<InkStroke> strokes;
  final List<InkPoint> activePoints;
  final Color penColor;
  final double penWidth;
  final bool highlighter;
  const _InkPainter(this.strokes, this.activePoints,
    {required this.penColor, required this.penWidth, required this.highlighter});

  @override
  void paint(Canvas canvas, Size size) {
    for (final stroke in strokes) {
      _render(canvas, size, stroke.points, Color(stroke.color),
        stroke.width, stroke.highlighter);
    }
    _render(canvas, size, activePoints, penColor, penWidth, highlighter);
  }

  void _render(Canvas canvas, Size size, List<InkPoint> points,
      Color color, double width, bool marker) {
    if (points.isEmpty) return;
    final paint = Paint()
      ..color = marker ? color.withValues(alpha: 0.34) : color
      ..strokeWidth = width * (marker ? 3.6 : 1)
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;
    final path = Path()..moveTo(points.first.x * size.width, points.first.y * size.height);
    for (var i = 1; i < points.length; i++) {
      path.lineTo(points[i].x * size.width, points[i].y * size.height);
    }
    if (points.length == 1) {
      canvas.drawCircle(Offset(points.first.x * size.width,
        points.first.y * size.height), width / 2, paint..style = PaintingStyle.fill);
    } else {
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _InkPainter oldDelegate) => true;
}

/// Vista previa persistente de la escritura a mano dentro de la propia nota.
class InkPreview extends StatelessWidget {
  final String? inkData;
  const InkPreview({super.key, required this.inkData});

  @override
  Widget build(BuildContext context) => Container(
    height: 176, decoration: BoxDecoration(
      color: Colors.white, border: Border.all(color: const Color(0xFFDDDDDD)),
      borderRadius: BorderRadius.circular(12)),
    clipBehavior: Clip.antiAlias,
    child: CustomPaint(size: Size.infinite,
      painter: _InkPainter(parseInk(inkData), const [],
        penColor: Colors.black, penWidth: 2.5, highlighter: false)));
}
