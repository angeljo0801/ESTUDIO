import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

/// Almacenamiento local sin cuentas ni internet. Para volúmenes grandes,
/// sustituir por una base de datos SQLite con migraciones.
class LocalStore {
  static const _notesKey = 'notes.v1';
  static const _historyKey = 'calculations.v1';
  static const _darkModeKey = 'darkMode.v1';
  static const _foldersKey = 'folders.v2';
  final SharedPreferences prefs;
  LocalStore(this.prefs);

  static Future<LocalStore> open() async =>
      LocalStore(await SharedPreferences.getInstance());

  List<Note> readNotes() {
    try {
      final data = jsonDecode(prefs.getString(_notesKey) ?? '[]') as List;
      return data.map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) { return []; }
  }

  List<Calculation> readHistory() {
    try {
      final data = jsonDecode(prefs.getString(_historyKey) ?? '[]') as List;
      return data.map((e) => Calculation.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) { return []; }
  }

  Future<void> writeNotes(List<Note> notes) async {
    await prefs.setString(_notesKey, jsonEncode(notes.map((e) => e.toJson()).toList()));
  }

  Future<void> writeHistory(List<Calculation> records) async {
    await prefs.setString(_historyKey, jsonEncode(records.map((e) => e.toJson()).toList()));
  }

  List<String> readFolders() =>
      List<String>.of(prefs.getStringList(_foldersKey) ?? <String>[]);

  Future<void> writeFolders(List<String> folders) async =>
      prefs.setStringList(_foldersKey, folders);

  bool get darkMode => prefs.getBool(_darkModeKey) ?? false;
  Future<void> setDarkMode(bool value) async {
    await prefs.setBool(_darkModeKey, value);
  }
}
