import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_quill/flutter_quill.dart' as quill;

import 'calculator_engine.dart';
import 'import_service.dart';
import 'ink_canvas.dart';
import 'pdf_viewer.dart';
import 'models.dart';
import 'storage.dart';
import 'unit_converter.dart';

const samsungGreen = Color(0xFF5DB625);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await LocalStore.open();
  runApp(NotesCalculatorApp(store: store));
}

class NotesCalculatorApp extends StatefulWidget {
  final LocalStore store;
  const NotesCalculatorApp({super.key, required this.store});
  @override
  State<NotesCalculatorApp> createState() => _NotesCalculatorAppState();
}

class _NotesCalculatorAppState extends State<NotesCalculatorApp> {
  late bool darkMode = widget.store.darkMode;
  @override
  Widget build(BuildContext context) {
    ThemeData makeTheme(Brightness brightness) {
      final scheme = ColorScheme.fromSeed(seedColor: samsungGreen, brightness: brightness);
      return ThemeData(
        useMaterial3: true,
        brightness: brightness,
        colorScheme: scheme,
        scaffoldBackgroundColor: brightness == Brightness.light
            ? const Color(0xFFFAFAFB) : const Color(0xFF101113),
        appBarTheme: const AppBarTheme(centerTitle: false, scrolledUnderElevation: 0),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        ),
      );
    }

    return MaterialApp(
      title: 'Notas Científicas',
      debugShowCheckedModeBanner: false,
      theme: makeTheme(Brightness.light),
      darkTheme: makeTheme(Brightness.dark),
      themeMode: darkMode ? ThemeMode.dark : ThemeMode.light,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        quill.FlutterQuillLocalizations.delegate,
      ],
      supportedLocales: const [Locale('es'), Locale('en')],
      home: HomePage(
        store: widget.store,
        darkMode: darkMode,
        toggleTheme: () {
          setState(() => darkMode = !darkMode);
          widget.store.setDarkMode(darkMode);
        },
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final LocalStore store;
  final bool darkMode;
  final VoidCallback toggleTheme;
  const HomePage({super.key, required this.store, required this.darkMode, required this.toggleTheme});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late List<Note> notes = widget.store.readNotes();
  late List<Calculation> history = widget.store.readHistory();
  int currentTab = 0;
  String notesView = 'active';
  String? folderFilter;
  late List<String> folders = widget.store.readFolders();
  bool importing = false;

  Future<void> _saveNote(Note note) async {
    if (note.folder.isNotEmpty && !folders.contains(note.folder)) {
      setState(() => folders.add(note.folder));
      await widget.store.writeFolders(folders);
    }
    final index = notes.indexWhere((n) => n.id == note.id);
    setState(() {
      if (index >= 0) {
        notes[index] = note;
      } else {
        notes.add(note);
      }
    });
    await widget.store.writeNotes(notes);
  }

  Future<void> _deleteNote(String id) async {
    final index = notes.indexWhere((n) => n.id == id);
    if (index == -1) return;
    setState(() => notes[index] = notes[index].copyWith(
      trashed: true, updatedAt: DateTime.now()));
    await widget.store.writeNotes(notes);
  }

  Future<void> _restoreNote(String id) async {
    final index = notes.indexWhere((n) => n.id == id);
    if (index == -1) return;
    setState(() => notes[index] = notes[index].copyWith(
      trashed: false, updatedAt: DateTime.now()));
    await widget.store.writeNotes(notes);
  }

  Future<void> _permanentlyDeleteNote(String id) async {
    setState(() => notes.removeWhere((n) => n.id == id));
    await widget.store.writeNotes(notes);
  }

  Future<void> _archiveNote(Note note) async {
    await _saveNote(note.copyWith(archived: !note.archived,
      updatedAt: DateTime.now()));
  }

  Future<void> _addFolder() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(context: context,
      builder: (ctx) => AlertDialog(title: const Text('Nueva carpeta'),
        content: TextField(controller: controller, autofocus: true,
          decoration: const InputDecoration(hintText: 'Nombre de la carpeta')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Crear')),
        ]));
    controller.dispose();
    if (name == null || name.isEmpty || folders.contains(name)) return;
    setState(() => folders.add(name));
    await widget.store.writeFolders(folders);
  }

  Future<void> _importNote() async {
    if (importing) return;
    setState(() => importing = true);
    try {
      final imported = await ImportService.pickAndImport();
      if (imported == null) return;
      final now = DateTime.now();
      final note = Note(id: newId(), title: imported.title,
        content: imported.content, createdAt: now, updatedAt: now,
        folder: imported.folder, tags: imported.tags,
        pdfPath: imported.pdfPath, sourceName: imported.sourceName);
      if (note.folder.isNotEmpty && !folders.contains(note.folder)) {
        setState(() => folders.add(note.folder));
        await widget.store.writeFolders(folders);
      }
      await _saveNote(note);
      if (!mounted) return;
      setState(() { notesView = 'active'; folderFilter = null; currentTab = 0; });
      await _openNote(note);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('No se pudo importar el archivo: $error')));
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> _recordCalculation(Calculation record) async {
    setState(() {
      history.removeWhere((c) => c.id == record.id);
      history.insert(0, record);
      if (history.length > 500) history = history.take(500).toList();
    });
    await widget.store.writeHistory(history);
  }

  Future<void> _openNote([Note? note]) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => NoteEditorPage(
        initialNote: note,
        history: history,
        onSave: _saveNote,
        onDelete: _deleteNote,
        onRecord: _recordCalculation,
        folders: folders,
      ),
    ));
  }

  Future<void> _saveCalculationToNote(Calculation record) async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text('Guardar cálculo en una nota', style: Theme.of(sheetContext).textTheme.titleLarge),
            ),
            ListTile(
              leading: const Icon(Icons.note_add_outlined),
              title: const Text('Crear nota nueva'),
              onTap: () => Navigator.pop(sheetContext, '__NEW__'),
            ),
            Flexible(
              child: ListView(shrinkWrap: true, children: notes.map((note) => ListTile(
                leading: const Icon(Icons.description_outlined),
                title: Text(note.title.isEmpty ? 'Sin título' : note.title, maxLines: 1),
                subtitle: Text(note.content, maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(sheetContext, note.id),
              )).toList()),
            ),
          ]),
        ),
      ),
    );
    if (chosen == null || !mounted) return;
    final now = DateTime.now();
    final expressionText = '${record.expression} = ${record.result}';
    final Note note;
    if (chosen == '__NEW__') {
      note = Note(id: newId(), title: 'Cálculo ${_date(now)}', content: expressionText,
        createdAt: now, updatedAt: now);
    } else {
      final existing = notes.where((n) => n.id == chosen).firstOrNull;
      if (existing == null) return;
      final separator = existing.content.trim().isEmpty ? '' : '\n\n';
      quill.Document doc;
      try {
        doc = existing.richText == null
          ? quill.Document()
          : quill.Document.fromJson(jsonDecode(existing.richText!) as List<dynamic>);
      } catch (_) { doc = quill.Document(); }
      if (existing.richText == null && existing.content.isNotEmpty) {
        doc.insert(0, existing.content);
      }
      doc.insert(doc.length - 1, '$separator$expressionText');
      note = existing.copyWith(
        content: '${existing.content}$separator$expressionText',
        richText: jsonEncode(doc.toDelta().toJson()), updatedAt: now);
    }
    await _saveNote(note);
    await _recordCalculation(record.copyWith(noteId: note.id));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Cálculo guardado en la nota')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(currentTab == 0
          ? (notesView == 'trash' ? 'Papelera' :
             notesView == 'archive' ? 'Archivo' : (folderFilter ?? 'Mis notas'))
          : 'Calculadora'),
        actions: [
          if (currentTab == 0) ...[
            if (importing) const Padding(padding: EdgeInsets.all(16),
              child: SizedBox(width: 20, height: 20,
                child: CircularProgressIndicator(strokeWidth: 2)))
            else IconButton(tooltip: 'Importar PDF, TXT, MD o NCNOTE',
              onPressed: _importNote,
              icon: const Icon(Icons.file_open_outlined)),
            IconButton(tooltip: 'Crear carpeta', onPressed: _addFolder,
              icon: const Icon(Icons.create_new_folder_outlined)),
          ],
          IconButton(
            tooltip: widget.darkMode ? 'Tema claro' : 'Tema oscuro',
            onPressed: widget.toggleTheme,
            icon: Icon(widget.darkMode ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
          ),
          const SizedBox(width: 8),
        ],
      ),
      drawer: Drawer(child: SafeArea(child: ListView(children: [
        const ListTile(title: Text('Notas Científicas',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22))),
        ListTile(leading: const Icon(Icons.notes_outlined), title: const Text('Todas las notas'),
          onTap: () {setState(() {notesView = 'active'; folderFilter = null;}); Navigator.pop(context);}),
        ListTile(leading: const Icon(Icons.archive_outlined), title: const Text('Archivadas'),
          onTap: () {setState(() {notesView = 'archive'; folderFilter = null;}); Navigator.pop(context);}),
        ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Papelera'),
          onTap: () {setState(() {notesView = 'trash'; folderFilter = null;}); Navigator.pop(context);}),
        const Divider(),
        const ListTile(title: Text('Carpetas')),
        for (final folder in folders)
          ListTile(leading: const Icon(Icons.folder_outlined), title: Text(folder),
            onTap: () {setState(() {notesView = 'active'; folderFilter = folder;}); Navigator.pop(context);}),
        ListTile(leading: const Icon(Icons.create_new_folder_outlined),
          title: const Text('Nueva carpeta'), onTap: () { Navigator.pop(context); _addFolder(); }),
      ]))),
      body: IndexedStack(index: currentTab, children: [
        NotesList(notes: notes, onOpen: _openNote, view: notesView,
          folderFilter: folderFilter, onRestore: _restoreNote,
          onPermanentDelete: _permanentlyDeleteNote, onArchive: _archiveNote),
        CalculatorPage(
          history: history,
          onSave: _recordCalculation,
          onSaveToNote: _saveCalculationToNote,
        ),
      ]),
      floatingActionButton: currentTab == 0 && notesView == 'active'
          ? FloatingActionButton.extended(
              onPressed: () => _openNote(),
              icon: const Icon(Icons.edit_note_rounded), label: const Text('Nueva nota'))
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentTab,
        onDestinationSelected: (index) => setState(() => currentTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.note_alt_outlined), selectedIcon: Icon(Icons.note_alt), label: 'Notas'),
          NavigationDestination(icon: Icon(Icons.calculate_outlined), selectedIcon: Icon(Icons.calculate), label: 'Calculadora'),
        ],
      ),
    );
  }
}

class NotesList extends StatefulWidget {
  final List<Note> notes;
  final void Function(Note?) onOpen;
  final String view;
  final String? folderFilter;
  final Future<void> Function(String) onRestore;
  final Future<void> Function(String) onPermanentDelete;
  final Future<void> Function(Note) onArchive;
  const NotesList({super.key, required this.notes, required this.onOpen,
    required this.view, required this.folderFilter,
    required this.onRestore, required this.onPermanentDelete,
    required this.onArchive});
  @override
  State<NotesList> createState() => _NotesListState();
}

class _NotesListState extends State<NotesList> {
  String search = '';
  @override
  Widget build(BuildContext context) {
    final filtered = widget.notes.where((n) {
      if (widget.view == 'trash') return n.trashed;
      if (n.trashed) return false;
      if (widget.view == 'archive') return n.archived;
      if (n.archived) return false;
      if (widget.folderFilter != null && n.folder != widget.folderFilter) return false;
      return true;
    }).where((n) =>
      '${n.title} ${n.content} ${n.tags.join(' ')} ${n.sourceName ?? ''}'
        .toLowerCase().contains(search.toLowerCase())).toList()
      ..sort((a, b) {
        if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
        return b.updatedAt.compareTo(a.updatedAt);
      });
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: TextField(
          onChanged: (value) => setState(() => search = value),
          decoration: InputDecoration(hintText: 'Buscar en las notas',
            prefixIcon: const Icon(Icons.search_rounded), filled: true,
            fillColor: Theme.of(context).colorScheme.surfaceContainerLow,
            border: OutlineInputBorder(borderSide: BorderSide.none,
              borderRadius: BorderRadius.circular(24))),
        )),
      Expanded(child: filtered.isEmpty
        ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.sticky_note_2_outlined, size: 68,
              color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(search.isEmpty ? 'Aquí todavía no hay notas' : 'No hay resultados',
              style: Theme.of(context).textTheme.titleMedium),
          ]))
        : ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
            itemCount: filtered.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, index) {
              final note = filtered[index];
              return Card(elevation: 0,
                color: Theme.of(context).colorScheme.surfaceContainerLow,
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  title: Row(children: [
                    Expanded(child: Text(note.title.isEmpty ? 'Sin título' : note.title,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600))),
                    if (note.pinned) const Icon(Icons.push_pin, size: 16),
                    if (note.pdfPath != null) const Icon(Icons.picture_as_pdf, size: 16),
                    if (note.inkData != null) const Icon(Icons.draw, size: 16),
                  ]),
                  subtitle: Padding(padding: const EdgeInsets.only(top: 8),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(note.content.isEmpty ? 'Nota vacía' : note.content,
                        maxLines: 2, overflow: TextOverflow.ellipsis),
                      if (note.tags.isNotEmpty) Text(note.tags.map((s) => '#$s').join(' '),
                        maxLines: 1, style: Theme.of(context).textTheme.labelSmall),
                      const SizedBox(height: 8),
                      Text(_date(note.updatedAt), style: Theme.of(context).textTheme.labelSmall),
                    ])),
                  trailing: PopupMenuButton<String>(
                    tooltip: 'Opciones de nota',
                    onSelected: (action) {
                      if (action == 'restore') widget.onRestore(note.id);
                      if (action == 'permanent') widget.onPermanentDelete(note.id);
                      if (action == 'archive') widget.onArchive(note);
                    },
                    itemBuilder: (_) => widget.view == 'trash'
                      ? const [PopupMenuItem(value: 'restore', child: Text('Restaurar')),
                          PopupMenuItem(value: 'permanent', child: Text('Eliminar definitivamente'))]
                      : [PopupMenuItem(value: 'archive',
                          child: Text(note.archived ? 'Desarchivar' : 'Archivar'))]),
                  onTap: () => widget.onOpen(note),
                ),
              );
            })),
    ]);
  }
}

class NoteEditorPage extends StatefulWidget {
  final Note? initialNote;
  final List<Calculation> history;
  final Future<void> Function(Note) onSave;
  final Future<void> Function(String) onDelete;
  final Future<void> Function(Calculation) onRecord;
  final List<String> folders;

  const NoteEditorPage({super.key, this.initialNote, required this.history,
    required this.onSave, required this.onDelete, required this.onRecord, required this.folders});
  @override
  State<NoteEditorPage> createState() => _NoteEditorPageState();
}

class _NoteEditorPageState extends State<NoteEditorPage> {
  late final String noteId = widget.initialNote?.id ?? newId();
  late final DateTime createdAt = widget.initialNote?.createdAt ?? DateTime.now();
  late final title = TextEditingController(text: widget.initialNote?.title ?? '');
  late final quill.QuillController editor = _makeEditor();
  late bool pinned = widget.initialNote?.pinned ?? false;
  late bool trashed = widget.initialNote?.trashed ?? false;
  late bool archived = widget.initialNote?.archived ?? false;
  late String folder = widget.initialNote?.folder ?? '';
  late List<String> tags = List.of(widget.initialNote?.tags ?? []);
  late String? inkData = widget.initialNote?.inkData;
  late String? pdfPath = widget.initialNote?.pdfPath;
  bool deleted = false;
  Timer? _autoSave;

  quill.QuillController _makeEditor() {
    quill.Document document;
    try {
      final raw = widget.initialNote?.richText;
      if (raw != null && raw.isNotEmpty) {
        document = quill.Document.fromJson(jsonDecode(raw) as List<dynamic>);
      } else {
        document = quill.Document();
        final initial = widget.initialNote?.content ?? '';
        if (initial.isNotEmpty) document.insert(0, initial);
      }
    } catch (_) {
      document = quill.Document();
      final initial = widget.initialNote?.content ?? '';
      if (initial.isNotEmpty) document.insert(0, initial);
    }
    return quill.QuillController(document: document,
      selection: const TextSelection.collapsed(offset: 0));
  }

  @override
  void initState() {
    super.initState();
    title.addListener(_scheduleSave);
    editor.addListener(_scheduleSave);
  }

  void _scheduleSave() {
    _autoSave?.cancel();
    _autoSave = Timer(const Duration(milliseconds: 700), _save);
  }

  Future<void> _save() async {
    if (deleted) return;
    final body = editor.document.toPlainText().trimRight();
    if (widget.initialNote == null && title.text.trim().isEmpty &&
        body.isEmpty && inkData == null && pdfPath == null) return;
    await widget.onSave(Note(id: noteId, title: title.text.trim(),
      content: body, createdAt: createdAt, updatedAt: DateTime.now(),
      pinned: pinned, trashed: trashed, archived: archived,
      folder: folder, tags: tags,
      richText: jsonEncode(editor.document.toDelta().toJson()),
      inkData: inkData, pdfPath: pdfPath,
      sourceName: widget.initialNote?.sourceName));
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(title: const Text('¿Enviar a papelera?'),
        content: const Text('Podrás restaurar la nota desde Papelera.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Mover')),
        ]));
    if (confirmed != true) return;
    deleted = true;
    await widget.onDelete(noteId);
    if (mounted) Navigator.pop(context);
  }

  void _insertCalculation(Calculation record) {
    final textToInsert = '\n${record.expression} = ${record.result}\n';
    final selection = editor.selection;
    final offset = selection.isValid ? selection.start :
      editor.document.length - 1;
    final length = selection.isValid ? selection.end - selection.start : 0;
    editor.replaceText(offset, length, textToInsert,
      TextSelection.collapsed(offset: offset + textToInsert.length));
    widget.onRecord(record.copyWith(noteId: noteId));
    _scheduleSave();
  }

  Future<void> _openCalculator() async {
    await Navigator.push<void>(context, MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Calculadora científica')),
        body: CalculatorPage(history: widget.history, onSave: widget.onRecord,
          onInsert: _insertCalculation),
      ),
    ));
  }

  Future<void> _openInk() async {
    final updated = await Navigator.push<String>(context,
      MaterialPageRoute(builder: (_) => InkCanvasPage(initialInk: inkData)));
    if (updated == null || !mounted) return;
    setState(() => inkData = updated);
    _scheduleSave();
  }

  Future<void> _editMeta() async {
    final tagController = TextEditingController(text: tags.join(', '));
    final folderController = TextEditingController(text: folder);
    final changed = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(title: const Text('Organizar nota'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: folderController,
            decoration: const InputDecoration(labelText: 'Carpeta')),
          const SizedBox(height: 12),
          TextField(controller: tagController,
            decoration: const InputDecoration(labelText: 'Etiquetas (separadas por comas)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar')),
        ]));
    if (changed == true) {
      setState(() {
        folder = folderController.text.trim();
        tags = tagController.text.split(',').map((e) => e.trim())
          .where((e) => e.isNotEmpty).toSet().toList();
      });
      _scheduleSave();
    }
    folderController.dispose();
    tagController.dispose();
  }

  @override
  void dispose() {
    _autoSave?.cancel();
    title.dispose();
    editor.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(canPop: false, onPopInvokedWithResult: (didPop, _) async {
      if (didPop) return;
      await _save();
      if (context.mounted) Navigator.pop(context);
    }, child: Scaffold(
      appBar: AppBar(
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () async {
          await _save();
          if (context.mounted) Navigator.pop(context);
        }),
        actions: [
          IconButton(tooltip: 'Carpeta y etiquetas', onPressed: _editMeta,
            icon: const Icon(Icons.folder_open_outlined)),
          IconButton(tooltip: 'Fijar nota', icon: Icon(pinned ? Icons.push_pin : Icons.push_pin_outlined),
            onPressed: () {setState(() => pinned = !pinned); _scheduleSave();}),
          if (!trashed) IconButton(tooltip: 'Mover a papelera',
            icon: const Icon(Icons.delete_outline), onPressed: _delete),
          IconButton(tooltip: 'Guardar', icon: const Icon(Icons.check_rounded),
            onPressed: () async {await _save(); if (context.mounted) Navigator.pop(context);}),
        ],
      ),
      body: Padding(padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Column(children: [
          Padding(padding: const EdgeInsets.symmetric(horizontal: 8),
            child: TextField(controller: title, maxLines: 2, minLines: 1,
              textCapitalization: TextCapitalization.sentences,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w600),
              decoration: const InputDecoration(hintText: 'Título', border: InputBorder.none))),
          Align(alignment: Alignment.centerLeft,
            child: Padding(padding: const EdgeInsets.only(left: 8),
              child: Text('${_date(createdAt)}  •  ${folder.isEmpty ? 'Sin carpeta' : folder}',
                style: Theme.of(context).textTheme.labelSmall))),
          const SizedBox(height: 8),
          if (pdfPath != null) ListTile(
            leading: const Icon(Icons.picture_as_pdf_outlined),
            title: const Text('Ver PDF original'),
            subtitle: Text(widget.initialNote?.sourceName ?? 'Documento adjunto'),
            onTap: () => Navigator.push(context, MaterialPageRoute<void>(
              builder: (_) => AttachedPdfPage(path: pdfPath!)))),
          if (inkData != null) InkWell(onTap: _openInk,
            child: Column(children: [
              const Row(children: [Icon(Icons.draw_outlined, size: 18),
                SizedBox(width: 8), Text('Escritura con S Pen  ·  tocar para editar')]),
              const SizedBox(height: 6),
              InkPreview(inkData: inkData),
            ])),
          quill.QuillSimpleToolbar(controller: editor,
            config: const quill.QuillSimpleToolbarConfig()),
          const SizedBox(height: 8),
          Expanded(child: quill.QuillEditor.basic(controller: editor,
            config: const quill.QuillEditorConfig(
              placeholder: 'Escribe tus apuntes aquí…'))),
        ])),
      bottomNavigationBar: SafeArea(top: false,
        child: Padding(padding: const EdgeInsets.fromLTRB(10, 5, 10, 10),
          child: Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: _openInk,
              icon: const Icon(Icons.draw_outlined), label: const Text('S Pen'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.icon(onPressed: _openCalculator,
              icon: const Icon(Icons.calculate_outlined), label: const Text('Calculadora'))),
          ]))),
    ));
  }
}

class CalculatorPage extends StatefulWidget {
  final List<Calculation> history;
  final Future<void> Function(Calculation) onSave;
  final Future<void> Function(Calculation)? onSaveToNote;
  final void Function(Calculation)? onInsert;

  const CalculatorPage({super.key, required this.history, required this.onSave,
    this.onSaveToNote, this.onInsert});

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  static const engine = CalculatorEngine();
  String expression = '';
  String result = '';
  bool scientific = false;
  bool radians = false;
  bool second = false;
  Calculation? lastRecord;

  Calculation? get currentCalculation {
    if (expression.isEmpty || result.isEmpty || result == 'Error') return null;
    if (lastRecord != null && lastRecord!.expression == expression &&
        lastRecord!.result == result && lastRecord!.radians == radians) return lastRecord;
    return Calculation(id: newId(), expression: expression, result: result,
      date: DateTime.now(), radians: radians);
  }

  void _refresh() {
    try {
      result = expression.isEmpty ? '' : engine.calculate(expression, radians: radians);
    } catch (_) { result = ''; }
    setState(() {});
  }

  void _type(String value) {
    setState(() {
      if (lastRecord != null && value != 'C' && value != '⌫') {
        final previousResult = lastRecord!.result;
        if (['+', '−', '×', '÷', 'xʸ', 'x²', '%', 'x!'].contains(value)) {
          expression = previousResult;
        } else {
          expression = '';
        }
      }
      if (value == 'C') {
        expression = '';
        result = '';
        lastRecord = null;
        return;
      }
      if (value == '⌫') {
        if (expression.isNotEmpty) expression = expression.substring(0, expression.length - 1);
      } else if (value == '()') {
        final opened = '('.allMatches(expression).length;
        final closed = ')'.allMatches(expression).length;
        expression += opened > closed && expression.isNotEmpty &&
          !'+−×÷^('.contains(expression[expression.length - 1]) ? ')' : '(';
      } else if (value == '+/−') {
        if (expression.startsWith('−')) {
          expression = expression.substring(1);
        } else {
          expression = '−$expression';
        }
      } else if (value == '1/x') {
        expression += '1/(';
      } else if (value == 'x²') {
        expression += '^2';
      } else if (value == 'xʸ') {
        expression += '^';
      } else if (value == '10ˣ') {
        expression += '10^(';
      } else if (value == 'eˣ') {
        expression += 'exp(';
      } else if (value == '|x|') {
        expression += 'abs(';
      } else if (value == '√') {
        expression += '√(';
      } else if (value == 'x!') {
        expression += '!';
      } else if (value == 'π' || value == 'e' || value == '%' || value == '.' ||
        value == '+' || value == '−' || value == '×' || value == '÷' ||
        RegExp(r'^\d$').hasMatch(value)) {
        expression += value;
      } else if (['sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'ln', 'log'].contains(value)) {
        expression += '$value(';
      }
      lastRecord = null;
    });
    _refresh();
  }

  Future<void> _equals() async {
    try {
      final computed = engine.calculate(expression, radians: radians);
      final record = Calculation(id: newId(), expression: expression, result: computed,
        date: DateTime.now(), radians: radians);
      setState(() {result = computed; lastRecord = record;});
      await widget.onSave(record);
    } catch (_) {
      setState(() => result = 'Error');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Comprueba la operación')));
    }
  }

  Future<void> _insert() async {
    final record = currentCalculation;
    if (record == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Primero introduce una operación válida')));
      return;
    }
    widget.onInsert!(record);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _saveToNote() async {
    final record = currentCalculation;
    if (record == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Primero introduce una operación válida')));
      return;
    }
    await widget.onSaveToNote!(record);
  }

  Future<void> _readClipboard() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim() ?? '';
    if (!mounted || text.isEmpty) return;
    try {
      engine.evaluate(text, radians: radians);
      setState(() {expression = text; lastRecord = null;});
      _refresh();
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El portapapeles no contiene una operación compatible')));
    }
  }

  void _showHistory() {
    showModalBottomSheet<void>(context: context, showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: SizedBox(height: MediaQuery.of(sheetContext).size.height * 0.65,
          child: Column(children: [
            Padding(padding: const EdgeInsets.all(16),
              child: Row(children: [
                Expanded(child: Text('Historial', style: Theme.of(sheetContext).textTheme.titleLarge)),
                Text('${widget.history.length} operaciones'),
              ])),
            Expanded(child: widget.history.isEmpty
              ? const Center(child: Text('Aún no tienes cálculos guardados'))
              : ListView.separated(
                  itemCount: widget.history.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, index) {
                    final record = widget.history[index];
                    return ListTile(
                      title: Text(record.expression, textAlign: TextAlign.right),
                      subtitle: Text('= ${record.result}', textAlign: TextAlign.right,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 19)),
                      leading: record.noteId == null
                        ? const Icon(Icons.history) : const Icon(Icons.bookmark_added_outlined),
                      onTap: () {
                        setState(() {
                          expression = record.expression;
                          radians = record.radians;
                          result = record.result;
                          lastRecord = record;
                        });
                        Navigator.pop(sheetContext);
                      },
                    );
                  },
                )),
          ])),
      ));
  }

  Widget _key(String key, {bool small = false}) {
    final theme = Theme.of(context);
    final dark = theme.brightness == Brightness.dark;
    final operator = ['+', '−', '×', '÷'].contains(key);
    final isEqual = key == '=';
    final clear = key == 'C';
    final background = isEqual ? samsungGreen : operator
      ? (dark ? const Color(0xFF36383A) : const Color(0xFFE8E8EA))
      : (dark ? const Color(0xFF242528) : const Color(0xFFF1F1F3));
    final foreground = isEqual ? Colors.white : (operator
      ? samsungGreen : (clear ? const Color(0xFFEB6556) : theme.colorScheme.onSurface));
    return Material(
      color: background,
      borderRadius: BorderRadius.circular(100),
      elevation: dark ? 0 : 0.7,
      child: InkWell(
        borderRadius: BorderRadius.circular(100),
        onTap: () {
          if (key == '=') { _equals(); return; }
          if (key == '2nd') { setState(() => second = !second); return; }
          if (key == 'Deg' || key == 'Rad') {
            setState(() => radians = !radians);
            _refresh();
            return;
          }
          _type(key);
        },
        child: Center(child: Text(key,
          style: TextStyle(fontSize: small ? 16 : 24,
            fontWeight: isEqual ? FontWeight.w700 : FontWeight.w400,
            color: foreground))),
      ),
    );
  }

  Widget _keyGrid(List<String> keys, {bool small = false}) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4, mainAxisSpacing: small ? 7 : 9,
        crossAxisSpacing: 10, childAspectRatio: small ? 2.0 : 1.56,
      ),
      itemCount: keys.length,
      itemBuilder: (_, index) => _key(keys[index], small: small),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scientificKeys = [
      '2nd', radians ? 'Rad' : 'Deg', '√', 'x²',
      if (second) ...['asin', 'acos', 'atan', 'xʸ']
      else ...['sin', 'cos', 'tan', 'xʸ'],
      'ln', 'log', '1/x', 'x!',
      'π', 'e', '|x|', '10ˣ',
    ];
    const standardKeys = [
      'C', '()', '%', '÷',
      '7', '8', '9', '×',
      '4', '5', '6', '−',
      '1', '2', '3', '+',
      '+/−', '0', '.', '=',
    ];
    return LayoutBuilder(builder: (context, constraints) {
      final compact = constraints.maxHeight < 720;
      return SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            SizedBox(height: scientific ? (compact ? 78 : 130) : (compact ? 140 : 210),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 4, 22, 4),
                child: Column(mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end, children: [
                    SizedBox(width: double.infinity,
                      child: SingleChildScrollView(scrollDirection: Axis.horizontal, reverse: true,
                        child: Text(expression.isEmpty ? '0' : expression,
                          maxLines: 1, style: TextStyle(
                            fontSize: scientific ? 31 : 37,
                            fontWeight: FontWeight.w400,
                            color: Theme.of(context).colorScheme.onSurface)))),
                    const SizedBox(height: 6),
                    SizedBox(height: 38, child: Text(result.isEmpty ? ' ' : '= $result',
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 24,
                        color: Theme.of(context).colorScheme.onSurfaceVariant))),
                  ]),
              )),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              IconButton(tooltip: 'Historial', onPressed: _showHistory,
                icon: const Icon(Icons.history_rounded)),
              IconButton(tooltip: 'Conversor de unidades', onPressed: () =>
                showModalBottomSheet<void>(context: context, isScrollControlled: true,
                  showDragHandle: true, builder: (_) => const UnitConverterSheet()),
                icon: const Icon(Icons.straighten_outlined)),
              IconButton(tooltip: scientific ? 'Modo estándar' : 'Modo científico',
                onPressed: () => setState(() => scientific = !scientific),
                icon: const Icon(Icons.calculate_outlined),
                color: scientific ? samsungGreen : null),
              IconButton(tooltip: 'Pegar operación', onPressed: _readClipboard,
                icon: const Icon(Icons.content_paste_outlined)),
              IconButton(tooltip: 'Borrar último carácter', onPressed: () => _type('⌫'),
                icon: const Icon(Icons.backspace_outlined), color: samsungGreen),
            ]),
            const Divider(indent: 16, endIndent: 16),
            if (scientific) _keyGrid(scientificKeys, small: true),
            _keyGrid(standardKeys),
            if (widget.onSaveToNote != null || widget.onInsert != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                child: FilledButton.icon(
                  onPressed: widget.onInsert != null ? _insert : _saveToNote,
                  icon: const Icon(Icons.save_alt_rounded),
                  label: Text(widget.onInsert != null ? 'Insertar cálculo en la nota' : 'Guardar en una nota'),
                ),
              ),
          ]),
        ),
      );
    });
  }
}

String _date(DateTime date) {
  String two(int n) => n.toString().padLeft(2, '0');
  return '${two(date.day)}/${two(date.month)}/${date.year} ${two(date.hour)}:${two(date.minute)}';
}
