import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_pdf_text/flutter_pdf_text.dart';
import 'package:path_provider/path_provider.dart';

/// Contenido transferido desde ChatGPT o desde archivos locales del teléfono.
/// La especificación NCNOTE v1 admite título, contenido, carpeta y etiquetas.
class ImportedNote {
  final String title;
  final String content;
  final String folder;
  final List<String> tags;
  final String? pdfPath;
  final String sourceName;

  const ImportedNote({required this.title, required this.content,
    this.folder = '', this.tags = const [], this.pdfPath,
    required this.sourceName});
}

class ImportService {
  static const supportedExtensions = ['txt', 'md', 'pdf', 'ncnote'];

  static Future<ImportedNote?> pickAndImport() async {
    final selection = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: supportedExtensions,
      allowMultiple: false,
      withData: true,
    );
    if (selection == null || selection.files.isEmpty) return null;
    return importPickedFile(selection.files.single);
  }

  static Future<ImportedNote> importPickedFile(PlatformFile chosen) async {
    final name = chosen.name;
    final ext = name.split('.').last.toLowerCase();
    if (!supportedExtensions.contains(ext)) {
      throw const FormatException('Formato no admitido');
    }
    final bytes = chosen.bytes ??
      (chosen.path == null ? null : await File(chosen.path!).readAsBytes());
    if (bytes == null) throw const FileSystemException('No se pudo leer el archivo');
    return importBytes(bytes, name: name);
  }

  static Future<ImportedNote> importBytes(List<int> bytes,
      {required String name}) async {
    final ext = name.split('.').last.toLowerCase();
    final title = name.replaceFirst(RegExp(r'\.[^.]+$'), '');
    if (ext == 'pdf') {
      final saved = await _keepPdf(bytes, name);
      final pdf = await PDFDoc.fromPath(saved);
      final content = (await pdf.text).trim();
      return ImportedNote(title: title,
        content: content.isEmpty
            ? 'PDF importado: $name\n\nNo se detectó una capa de texto. '
              'El PDF original está adjunto; para convertir un escaneo se necesita OCR.'
            : content,
        pdfPath: saved, sourceName: name);
    }
    final text = utf8.decode(bytes, allowMalformed: true).replaceFirst('\uFEFF', '');
    if (ext == 'ncnote') {
      final parsed = jsonDecode(text);
      if (parsed is! Map<String, dynamic> ||
          parsed['format'] != 'notas-cientificas' || parsed['version'] != 1) {
        throw const FormatException('Archivo .ncnote inválido o no compatible');
      }
      return ImportedNote(
        title: (parsed['title'] as String?)?.trim().isNotEmpty == true
          ? parsed['title'] as String : title,
        content: parsed['content'] as String? ?? '',
        folder: parsed['folder'] as String? ?? '',
        tags: (parsed['tags'] as List<dynamic>? ?? []).map((x) => '$x').toList(),
        sourceName: name,
      );
    }
    if (ext == 'txt' || ext == 'md') {
      return ImportedNote(title: title, content: text, sourceName: name);
    }
    throw const FormatException('Formato no admitido');
  }

  static Future<String> _keepPdf(List<int> bytes, String originalName) async {
    final root = await getApplicationDocumentsDirectory();
    final folder = Directory('${root.path}/pdf_importados');
    if (!await folder.exists()) await folder.create(recursive: true);
    final safe = originalName.replaceAll(RegExp(r'[^A-Za-z0-9_.-]'), '_');
    final path = '${folder.path}/${DateTime.now().microsecondsSinceEpoch}_$safe';
    await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }
}
