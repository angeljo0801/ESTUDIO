class Note {
  final String id;
  final String title;
  final String content;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool pinned;
  final bool trashed;
  final bool archived;
  final String folder;
  final List<String> tags;
  /// Documento Delta de Flutter Quill; `content` mantiene texto indexable.
  final String? richText;
  /// JSON serializado de trazos de tinta, coordenadas relativas 0..1.
  final String? inkData;
  /// Copia persistente del PDF, dentro de los documentos privados de la app.
  final String? pdfPath;
  final String? sourceName;

  const Note({
    required this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.updatedAt,
    this.pinned = false,
    this.trashed = false,
    this.archived = false,
    this.folder = '',
    this.tags = const [],
    this.richText,
    this.inkData,
    this.pdfPath,
    this.sourceName,
  });

  Note copyWith({String? title, String? content, DateTime? updatedAt,
    bool? pinned, bool? trashed, bool? archived, String? folder,
    List<String>? tags, String? richText, String? inkData,
    String? pdfPath, String? sourceName}) => Note(
      id: id, title: title ?? this.title, content: content ?? this.content,
      createdAt: createdAt, updatedAt: updatedAt ?? this.updatedAt,
      pinned: pinned ?? this.pinned, trashed: trashed ?? this.trashed,
      archived: archived ?? this.archived, folder: folder ?? this.folder,
      tags: tags ?? this.tags, richText: richText ?? this.richText,
      inkData: inkData ?? this.inkData, pdfPath: pdfPath ?? this.pdfPath,
      sourceName: sourceName ?? this.sourceName,
    );

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'content': content,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(), 'pinned': pinned,
    'trashed': trashed, 'archived': archived, 'folder': folder,
    'tags': tags, 'richText': richText, 'inkData': inkData,
    'pdfPath': pdfPath, 'sourceName': sourceName,
  };

  factory Note.fromJson(Map<String, dynamic> json) => Note(
    id: json['id'] as String,
    title: json['title'] as String? ?? '',
    content: json['content'] as String? ?? '',
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
    pinned: json['pinned'] as bool? ?? false,
    trashed: json['trashed'] as bool? ?? false,
    archived: json['archived'] as bool? ?? false,
    folder: json['folder'] as String? ?? '',
    tags: (json['tags'] as List<dynamic>? ?? [])
      .map((tag) => tag.toString()).toList(),
    richText: json['richText'] as String?,
    inkData: json['inkData'] as String?,
    pdfPath: json['pdfPath'] as String?,
    sourceName: json['sourceName'] as String?,
  );
}

class Calculation {
  final String id;
  final String expression;
  final String result;
  final DateTime date;
  final String? noteId;
  final bool radians;

  const Calculation({required this.id, required this.expression, required this.result,
    required this.date, this.noteId, this.radians = false});

  Calculation copyWith({String? noteId}) => Calculation(
    id: id, expression: expression, result: result, date: date,
    noteId: noteId ?? this.noteId, radians: radians);

  Map<String, dynamic> toJson() => {
    'id': id, 'expression': expression, 'result': result,
    'date': date.toIso8601String(), 'noteId': noteId, 'radians': radians,
  };

  factory Calculation.fromJson(Map<String, dynamic> json) => Calculation(
    id: json['id'] as String,
    expression: json['expression'] as String,
    result: json['result'] as String,
    date: DateTime.parse(json['date'] as String),
    noteId: json['noteId'] as String?,
    radians: json['radians'] as bool? ?? false,
  );
}

String newId() => DateTime.now().microsecondsSinceEpoch.toString();
